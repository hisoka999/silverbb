<?
import_request_variables('gp', 'u_');
include "dbconnect.inc.php";
include "header.php";
eval ("\$header= \"" . template("header") . "\";");
eval ("\$footer= \"" . template("footer") . "\";");
if ($u_action == "activation") {
	$active = $dbconn->queryone("SELECT active 
	                               FROM login2_users 
	                               WHERE active=$u_rcode");
	if ($active != NULL) {
		$dbconn->query("UPDATE login2_users 
		                  SET active='1' 
		                  WHERE active=$u_rcode;");
		echo mysql_affected_rows() . " Ein User wurde aktiviert!";
	}
} else {
	if ($u_step != 2) {
		eval ("\$register= \"" . template("register") . "\";");
	}
	if ($u_step == 2) {

		//importieren der mit POST gesendeten Daten
		import_request_variables('p', 'frm_');
		$registration = "";
		//--------------------------------------------
		$name = $dbconn->queryone("SELECT count(*) as Anzahl 
		                  FROM login2_users 
		                  WHERE username='$frm_Name'");
		$name = htmlspecialchars($name);
		if ($frm_password == $frm_passwordwdh and $name == 0 and $frm_Name != "_" and $frm_Name != "-" and $frm_Name != "") {

			$email = trim($frm_mail);
			$registercode = md5(rand(1000, 9999));
			$regtext = "<B>Best&auml;tigung ihrer Anmeldung</b><br><br>\n\n
			    Aktivierungslink: $localdir/register.php?action=activation&rcode=$registercode\n\n
			    
			    mit freundlichen Fr&uuml;&szlig;en das $forumname Team";
			mail($email, "Best&auml;tigung ihrer Anmeldung", "$regtext<br>", "From: " . $adminmail) or die();
			$pw = md5($frm_password);
			//       echo "$frm_mail,$adminmail<br>"; 
			$dbconn->query("INSERT INTO login2_users " .
			"(username,password, active, level, email,group,regdate)" .
			" VALUES('$frm_Name','$pw','$registercode','1','$email',4,".time().");");

			$registration .= mysql_affected_rows() . " Ein User erstellt!";

			$registration .= "<br> Ihnen wird nun eine Freischaltungsmail zugrschickt.<br><a href='index.php'>Zurr&uuml;ckzur Startseite</a>";
			eval ("\$register= \"" . template("register_text") . "\";");
		} else {
			$errormessage = "";
			if ($frm_password != $frm_passwordwdh) {
				$errormessage .= "<b>Bitte &uuml;berpr&uuml;fen sie das Password. <br>Klicken sie <a href=register.php?action=&step=1>hier</a>.<br></b>";
			}
			if ($name > 0)
				$errormessage .= "<b>Bitte &uuml;berpr&uuml;fen sie den gew&auml;hlten <u>Namen</u>. Denn dieser ist schon vergeben oder ist unzul&auml;ssig.<br>Klicken sie <a href=register.php?action=&step=1>hier</a>.<br></b>";
			eval ("\$register= \"" . template("error_reg") . "\";");
		}

		//----------------------------------------------      
	}
}
echo $register;
?>
