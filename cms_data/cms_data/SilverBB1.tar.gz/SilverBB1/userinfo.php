<?php

//$rangzeichen="";
$state = $dbconn->query_first("Select * from login2_users WHere username='$_username'");
if($_username=="Gast"){
	$state["group"]=1;
	$state["Avatar"]="";
}
if ($state["Avatar"] != null) {
	$Avatar = "<img src=" . $state["Avatar"] . ">";
} else
	$Avatar = "";

//  $userrang=_SQL("SELECT Name FROM `group` WHERE `groupid`=".$state["group"],"Name");
$posts = $dbconn->queryone("SELECT count(*) as Anzahl FROM `posts` WHERE `Autor` = '$userid'");
$mygroup = $dbconn->query_first("SELECT * FROM `group` WHERE groupid=" . $state["group"]);
if ($mygroup["groupid"] == 4) {
	$state = $dbconn->query_first("SELECT * " .
	"FROM ranks " .
	"WHERE posts<='$posts' and groupid=" . $state["group"] . "  " .
	"ORDER BY ID DESC;");
	$userrang = $state["name"];
} else{
		$state["bild"] = $dbconn->queryone("SELECT bild FROM `ranks` WHERE groupid=" . $mygroup["groupid"]);
		$userrang = $dbconn->queryone("SELECT Name FROM `group` WHERE groupid=" . $state["group"]);
	}
$rangzeichen = $state["bild"];
$rangzeichen = str_replace("{", "<img src=\"", $rangzeichen);
$rangzeichen = str_replace("}", "\">", $rangzeichen);
?>   