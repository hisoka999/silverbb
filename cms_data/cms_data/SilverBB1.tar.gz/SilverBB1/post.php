<?php
$preview = "";
$postname="";
include "dbconnect.inc.php";

$u_action=$_GET["action"];
$u_step=(int)$_GET["step"];
$u_boardid=(int)$_GET["boardid"];
include "header.php";
eval ("\$header= \"" . template("header") . "\";");
if ($u_action == "zitat" && $u_step==0) {
	$u_postid=(int) $_GET["postid"];
	$zeile = $dbconn->query_first("Select * from posts WHERE ID=$u_postid");
	$name=$dbconn->queryone("SELECT username FROM login2_users WHERE ID=".$zeile["Autor"]);
	$zitat = "[quote][i]Orginal von&nbsp;" . $name . "[/i]\n";
	$zitat .= $zeile["Inhalt"] . "[/quote]";
	$Inhalt = "";
} else
if ($u_action == "edit") {
	$u_postid=(int) $_GET["postid"];
	$zeile = $dbconn->query_first("Select * from posts WHERE ID=$u_postid");
	$Inhalt = $zeile["Inhalt"];
	$postname=$zeile["Titel"];
	$zitat = "";
} else {
	$Inhalt = "";
	$zitat = "";
}
if ($u_step != 2 && $group['can_write_topic'] == 1) {
	if(isset($_GET["postid"]))$u_postid=(int) $_GET["postid"];
	else $u_postid=0;
	if(isset($_GET["threadid"]))$u_threadid=(int) $_GET["threadid"];
	else $u_threadid=0;
	if ($u_action == "create") {
		$form = "<form action='post.php?step=2&boardid=$u_boardid&action=$u_action&postid=0' method='post' name='post' onsubmit='return checkForm(this)'>";
	} else
	if ($u_action == "edit") {
		$form = "<form action='post.php?step=2&boardid=$u_boardid&action=$u_action&threadid=$u_threadid&postid=$u_postid' method='post' name='post' onsubmit='return checkForm(this)'>";
	} else {
		$form = "<form action='post.php?step=2&boardid=$u_boardid&action=$u_action&threadid=$u_threadid&postid=0' method='post'     name='post' onsubmit='return checkForm(this)'>";
	}
	if ($username == "Gast")
	eval ("\$reply_gast= \"" . template("reply_gast") . "\";");
	else
	$replygast = "";
	eval ("\$posting= \"" . template("posting") . "\";");
}
if ($u_step == 2 && $group['can_write_topic'] == 1) {



	//--------------------------------------------
	if (isset($_POST["preview"])) {
		if(isset($_GET["postid"]))$u_postid=(int) $_GET["postid"];
		else $u_postid=0;
		if(isset($_GET["threadid"]))$u_threadid=(int) $_GET["threadid"];
		else $u_threadid=0;
		if ($u_action == "create") {
			$form = "<form action='post.php?step=2&boardid=$u_boardid&action=$u_action&postid=0' method='post' name='post' onsubmit='return checkForm(this)'>";
		} else
		if ($u_action == "edit") {
			$form = "<form action='post.php?step=2&boardid=$u_boardid&action=$u_action&threadid=$u_threadid&postid=$u_postid' method='post' name='post' onsubmit='return checkForm(this)'>";
		} else {
			$form = "<form action='post.php?step=2&boardid=$u_boardid&action=$u_action&threadid=$u_threadid&postid=0' method='post'     name='post' onsubmit='return checkForm(this)'>";
		}

		$preview_text = prepare_code($_POST["inhalt"]);
		$postname=$_POST["Name"];
		$preview_text = smilie($preview_text);
		eval ("\$preview= \"" . template("preview") . "\";");
		if ($username == "Gast")
		eval ("\$reply_gast= \"" . template("reply_gast") . "\";");
		else
		$replygast = "";
		$zitat = $_POST["inhalt"];
		eval ("\$posting= \"" . template("posting") . "\";");
	} else {
		if(isset($_GET["threadid"]))$threadid=(int)$_GET["threadid"];
		if ($u_action == 'create') {
			if(strlen($_POST["Name"])>0)
			$dbconn->query("INSERT INTO thread " .
			"(Name,boardid,Autor,Datum,lastposttime)" .
			" VALUES('".$_POST["Name"]."','$u_boardid','$user_id','" . time() . "','" . time() . "');");
			//----------------------------------------------
			$threadid = $dbconn->queryone("SELECT max(ID) FROM thread WHERE Name ='" . stripslashes($_POST["Name"]) . "';");
		} else

		$frm_inhalt = parseURL($_POST["inhalt"]);
		//-----------------------------------------------
		if ($u_action != "edit" && (strlen($_POST["Name"])>0 || $user_id>0) && strlen($frm_inhalt) ) {
			$dbconn->query("UPDATE `thread` SET lastposttime = '" . time() . "' WHERE ID=$threadid");

			$dbconn->query("INSERT INTO posts " .
			"(Titel,Inhalt,boardid,threadid,Autor,Datum)" .
			"VALUES('".$_POST["Name"]."','".$frm_inhalt."'," .
			"'$u_boardid','$threadid','$user_id','" . time() . "');");
		}
		if ($u_action == "edit") {
			$frm_inhalt = parseURL($_POST["inhalt"]);
				
			$u_postid=(int)$_GET["postid"];
			$dbconn->query("UPDATE posts SET Inhalt='".$_POST["inhalt"]."', Titel='".$_POST["Name"]."' WHERE ID=".$u_postid);
				
		}
		$posting = "<center><a href='thread.php?boardid=$u_boardid&threadid=$threadid&action=thread'>Zum Thread</a><br><br>" .
		"<a href='index.php?action=forum'>Zur Startseite</a></center>";
	}
	/*
	 INSERT INTO `posts` VALUES (1, 1, 2, 'welches ist der beste maker', 'admin', 'sd');
	 INSERT INTO `posts` VALUES (2, 2, 1, 'test', 'gast', 'lol');
	 INSERT INTO `posts` VALUES (3, 1, 2, 'test', 'tester', 'test');
	 CREATE TABLE `posts` (
	 `ID` bigint(20) NOT NULL default '0',
	 `threadid` bigint(20) NOT NULL default '0',
	 `boardid` bigint(20) NOT NULL default '0',
	 `titel` varchar(50) NOT NULL default '',
	 `Autor` varchar(20) NOT NULL default '',
	 `Inhalt` text NOT NULL
	 ) TYPE=MyISAM;
	 */
}
eval ("\$footer= \"" . template("footer") . "\";");
eval ("\$reply= \"" . template("reply") . "\";");
echo $reply;
?>