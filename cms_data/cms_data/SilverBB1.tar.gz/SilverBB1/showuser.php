<?php
/**
 * @author Stefan Lüdtke
 * @copyright &copy; 2007 by www.silver-boards.de
 * @version 0.5
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */
$rangzeichen = "";
include "dbconnect.inc.php";
//import_request_variables('gp', 'u_');
include "header.php";
eval ("\$header= \"" . template("header") . "\";");
if (isset ($_GET["userid"]) && intval($_GET["userid"]) != 0)
	$userid = intval($_GET["userid"]);
else
	header("Location: index.php");

$data = $dbconn->query_first("SELECT * FROM login2_users WHERE ID=$userid");
$_username = $data["username"];

$birthday = explode("-", $data["birthday"]);
$day = $birthday[2];
$month = $birthday[1];
$years = $birthday[0];
$alter = 0;
if ($years != 0000) {
	$alter = date("Y") - $years;
	if ($month == date("m")) {
		if (date("d") < $day)
			$alter--;
	}
	elseif (date("m") < $month) $alter--;
}
$data["regdate"] = strftime("%d.%m.%Y", $data["regdate"]);

$posts = $dbconn->queryone("SELECT count(*) as Anzahl FROM `posts` WHERE `Autor` = $userid");
#userrang include
$state = $dbconn->query_first("Select * from login2_users WHere ID=$userid");
if($state["Avatar"]!="")$Avatar = "<img src=" . $state["Avatar"] . ">";
else $Avatar="";

$group = $dbconn->query_first("SELECT * FROM `group` WHERE groupid=" . $state["group"]);

if ($group["can_moderate_one"] == 1) {
	$state1["bild"] =$dbconn->queryone("SELECT bild FROM `ranks` WHERE groupid=" . $group["groupid"]);
	$userrang = $dbconn->queryone("SELECT Name FROM `group` WHERE groupid=" . $state["group"]);
}
else {
	$state1 = $dbconn->query_first("SELECT * FROM ranks WHERE posts<='$posts' and groupid=" . $state["group"] . "  ORDER BY ID DESC;");
	$userrang = $state1["name"];
}
$rangzeichen = $state1["bild"];
$rangzeichen = str_replace("{", "<img src=\"", $rangzeichen);
$rangzeichen = str_replace("}", "\"border=0>", $rangzeichen);
eval ("\$showuser= \"" . template("showuser") . "\";");
eval ("\$footer= \"" . template("footer") . "\";");
eval ("echo(\"" . template("showuser_index") . "\");");
?>