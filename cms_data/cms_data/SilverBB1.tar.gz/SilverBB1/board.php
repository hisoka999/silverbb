<?php
include "dbconnect.inc.php";
include "header.php";


switch ($_GET["boardid"])
{
  case 'cp':
  {
    header("Location: profil.php");
    exit;
  }
  case 'subs':
  {
    header("Location: profil.php");
    exit;
  }
  case 'search':
  {
    header("Location: search.php");
    exit;
  }
  case 'home':
  {
    header("Location: index.php");
    exit;
  }
  case 'pm':
  {
    header("Location: pms.php");
    exit;
  }
    
        
}

$boardid=(int) $_GET["boardid"];
if(is_null($boardid) || $boardid=="")header("Location: index.php");
$boardname=$dbconn->queryone("SELECT name FROM board WHERE ID=$boardid");

eval ("\$header= \"".template("header")."\";");

# Tabelllen anfang
$SQL=$dbconn->query("Select * from thread where boardid=$boardid ORDER BY thread_status DESC, lastposttime DESC");
$threads="";
  while($zeile=$dbconn->fetch_array($SQL))
  {
      $threadid=$zeile["ID"];      
      $test=$dbconn->query_first("SELECT count(*) as anzahl FROM `posts` WHERE `threadid`= $threadid and `Datum` >=  '".$old_time."' and Autor not like '$username'");      
      $autor=$dbconn->query_first("SELECT ID,username FROM login2_users WHERE ID=".$zeile["Autor"]);
      $Autor=$autor["username"];
      $userid=$autor["ID"];
      $posts=$dbconn->queryone("SELECT count(*) as anzahl FROM `posts`WHERE `threadid`= $threadid");
      $posts--;
 
      if ($test["anzahl"]==0)
      {
      if ($zeile["thread_status"]==1)
      $folder='<img src="./images/folder_announce.gif">';
      elseif ($zeile["close"]==1)
      $folder='<img src="./images/folder_lock.gif">';
      else
      $folder='<img src="./images/folder.gif">';
      }
      elseif($test["anzahl"]>=0)
      {
      if ($zeile["thread_status"]==1)
      $folder='<img src="./images/folder_announce_new.gif">';      
      elseif ($zeile["close"]==1)
      $folder='<img src="./images/folder_lock_new.gif">';
      elseif ($test["anzahl"]>0) 
      $folder='<img src="./images/folder_new.gif">';
      }           
      eval ("\$threads.= \"".template("board_threadbit")."\";");       
  }
if ($group['can_write_topic']==1)
{
$new_thread ="<a href='post.php?boardid=$boardid&action=create&step=1'><img src='" . "$imagefolder" . "/new_thread.gif' border=0></a>";
}
else
{ $new_thread="";}
$board_change=board_change($boardid);
eval ("\$footer= \"".template("footer")."\";");
eval ("echo(\"".template("board_index")."\");");
?>