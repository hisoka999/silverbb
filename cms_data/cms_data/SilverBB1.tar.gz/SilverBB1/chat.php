<?php
include "dbconnect.inc.php";
$u_action="";
include "header.php";
$logintime=time();
  if ($user_id!=0) eval ("\$chat= \"".template("chat_frameset")."\";");
  else eval ("\$chat= \"".template("chat_error")."\";");

echo $chat;
?>