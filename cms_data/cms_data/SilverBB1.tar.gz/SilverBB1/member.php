<?php
include "dbconnect.inc.php";


include "header.php";
eval ("\$header= \"".template("header")."\";");

# Tabelllen anfang
if(isset($_GET["order"]))$order=stripslashes($_GET["order"]);
else $order="ASC";
if($order!="ASC" && $order!="DESC")
{
	$order="ASC";
}
$SQL=$dbconn->query("SELECT * FROM login2_users ORDER BY username $order");

$pos=1;
$boardid="";
$threadid="";
$member_memberbit="";
while($zeile=$dbconn->fetch_array($SQL))
{
	$posts = $dbconn->queryone("SELECT count(*) FROM posts WHERE Autor=" . $zeile["ID"]);
	eval ("\$member_memberbit.= \"".template("member_memberbit")."\";");
}
eval ("\$footer= \"".template("footer")."\";");
eval ("echo(\"".template("member_index")."\");");
?>