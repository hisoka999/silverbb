<?php
include "acp/data.inc.php";
$session_link = true;

$user_id =(int) $_COOKIE['user_id'];

import_request_variables('gp', 'u_');
include "funktions.php";
include "header.php";
eval ("\$header= \"" . template("header") . "\";");
eval ("\$footer= \"" . template("footer") . "\";");
if (isset ($_GET['action']))
	$action1 = $_GET['action'];
elseif (isset ($_POST['action'])) $action1 = $_POST['action'];
if (!isset ($link))
	$link = "";
if (!isset ($ride))
	$ride = "";

if ($action1 == "delete" and $group["can_delete_topic"] == 1) {
	$dbconn->query("Delete from thread Where ID=$u_threadid");
	$SQL = $dbconn->query("Select * FROM posts WHERE threadid=$u_threadid");
	while ($zeile = $dbconn->fetch_array($SQL)) {
		$dbconn->query("Delete from posts Where ID=" . $zeile["ID"]);
	}
	header("Location: thread.php?boardid=$u_boardid&threadid=$u_threadid&action=thread");
}
if ($action1 == "close" and $group["can_clos_topic"] == 1) {
	$zeile = $dbconn->query_first("Select * FROM thread WHERE ID=$u_threadid");
	$close = $zeile["close"];
	if ($close == "0") {
		$dbconn->query("update thread Set close=1 Where ID='$u_threadid'");
	} else {
		$dbconn->query("update thread Set close=0 Where ID='$u_threadid'");
	}
	header("Location: thread.php?boardid=$u_boardid&threadid=$u_threadid&action=thread");
}
if ($action1 == "login") {
	// ############## Login ###############
	$kennwort = md5($_POST['kennwort']);
	$username = htmlspecialchars($_POST['username']);
	$usercheck = checkUser($username, $kennwort);
	if ($usercheck == 2) {
		$userdata = $dbconn->query_first("SELECT * FROM login2_users WHERE username = '$username' AND password = '$kennwort';");
		$sid_setting = $userdata["session_link"];
		$user_id = $userdata["ID"];
		$user_password = $kennwort;
		$dbconn->query("INSERT INTO user_online_table (userid) Values($user_id);");
		setcookie("user_id", "$user_id", time() + (3600 * 24 * 365));
		setcookie("user_password", "$user_password", time() + (3600 * 24 * 365));
		mybb_session_register("user_id");
		mybb_session_register("user_password");
		/* Session ID mitgeben, falls eingeschaltet.. */
		if (!$session_link) { // SID muss angeh�ngt werden.
			$filename = "";
			$querystring = "";
			@ list ($filename, $querystring) = @ explode("?", $ride);
			if (!$querystring) {
				$ride = $filename . "?sid=" . $sid;
			} else // querystring schon vorhanden => sid= ersetzen.
				{
				if (!stristr($querystring, "sid=")) // sid einfach anh�ngen
					{
					$querystring .= "&sid=" . $sid;
				} else // sid= ersetzen
					{
					$querystring = preg_replace("/sid=[a-zA-Z0-9]*/", "sid=", $querystring);
					$querystring = str_replace("sid=", "sid=$sid", $querystring);
				}
				$ride = $filename . "?" . $querystring;
			}

		}
		// Boardcookies verwenden...
		else {

			#setcookie("user_id", "$user_id", time()+(3600*24*365));
			#setcookie("user_password", "$user_password", time()+(3600*24*365));
		}
		header("Location: index.php?sid=$sid");
	} else {
		eval ("echo( \"" . template("error_login") . "\");");
		//  sleep(10);
	}

	//header ("Location: index.php?sid=$sid");
}
// ############## Logout ###############
if ($action1 == "logout") {
	$ride = urldecode($url_jump);
	if (!@ session_destroy())
		@ session_unset();
	setcookie("user_id");
	setcookie("user_password");
	if (isset ($_COOKIE['user_id']) && $_COOKIE['user_id'])
		$user_id = $_COOKIE['user_id'];
	elseif (isset ($_POST['user_id']) && $_POST['user_id']) $user_id = $_POST['user_id'];
	elseif (isset ($_GET['user_id']) && $_GET['user_id']) $user_id = $_GET['user_id'];
	else
		$user_id = "";
	$SQL =$dbconn->query("DELETE FROM user_online_table WHERE userid='".$user_id."';");
	setcookie("cbpassword");
	setcookie("votepoll");
	setcookie("sthreads");
	header("Location: index.php?sid=$sid");
}
// ############# Upload #############
if ($action1 == "ava") {
	$uploaddir = './images/Avatar/';
	if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploaddir . $_FILES['userfile']['name'])) {
	}
	$img = $uploaddir . $_FILES['userfile']['name'];

	import_request_variables('p', 'frm_');
	if ($img != $uploaddir) {
		$strSQL = "UPDATE login2_users set Avatar='$img',signature='$frm_sig', www='$frm_www', herkunft='$frm_herkunft', icq='$frm_icq', birthday='$frm_year-$frm_month-$frm_day' Where ID=$frm_userid;";
	} else {
		$strSQL = "UPDATE login2_users set signature='$frm_sig', www='$frm_www', herkunft='$frm_herkunft', icq='$frm_icq', birthday='$frm_year-$frm_month-$frm_day' Where ID=$frm_userid;";
	}
    $dbconn->query($strSQL);

	header("Location: profil.php?action=&sid=$sid");
}
if ($action1 == "postdel" and $group["can_delete_posts"] == 1) {
	header("Location: thread.php?boardid=$boardid&threadid=$threadid&action=thread");
}

if ($action1 == "style") {
	import_request_variables('p', 'frm_');
	$dbconn->query("UPDATE `login2_users` SET `style_set` ='$frm_style_id' WHERE ID = $user_id");
	//echo $frm_style_id;
	header("Location: profil.php?action=");
}
########## Thread set to announce ###############
/*Thread states
0- nothing
1- sicky
2- announce
*/
if ($action1 == "announce" and $group["can_moderate_one"] == 1) {
	
	$announce = $dbconn->queryone("SELECT thread_status FROM thread WHERE ID=$u_threadid");
	if ($announce == 0)
		$test = $dbconn->query("UPDATE thread SET thread_status=1 WHERE ID=$u_threadid");
	elseif ($announce == 1) $test = $dbconn->query("UPDATE thread SET thread_status=0 WHERE ID=$u_threadid");
	header("location: thread.php?boardid=$u_boardid&threadid=$u_threadid&action=thread");
}
exit;
?>    