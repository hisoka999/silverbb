<?php
						// Hostname oder IP des MySQL-Servers
						$Server = "localhost";
						// Username und Passwort zum einloggen in den Datenbankserver
						$Benutzer = "root";
						$Kennwort = "hisoka999";
						// Name der Datenbank
						$DB = "forum";
						?>