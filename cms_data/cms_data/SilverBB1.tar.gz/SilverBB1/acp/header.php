<?php
    include "./classes/db_conn_class.php";
    $dbconn= New dbconn;
    $dbconn->Server=$Server;
    $dbconn->Benutzer=$Benutzer;
    $dbconn->Kennwort=$Kennwort;
    $dbconn->DB=$DB;
    $dbconn->Conn();
if(ini_get("register_globals")) $register_globals=true;
else $register_globals=false;
$fctime = 30;
#
if(isset($_COOKIE['sid']) && $_COOKIE['sid']) $sid=$_COOKIE['sid'];
elseif(isset($_POST['sid']) && $_POST['sid']) $sid=$_POST['sid'];
elseif(isset($_GET['sid']) && $_GET['sid']) $sid=$_GET['sid'];
else $sid = "";




if(!$_SERVER['REQUEST_URI']) {
 	if($_SERVER['PATH_INFO']) $REQUEST_URI = $_SERVER['PATH_INFO'];
 	else $REQUEST_URI = $_SERVER['PHP_SELF'];
 	if($_SERVER['QUERY_STRING']) $REQUEST_URI .= "?" . $_SERVER['QUERY_STRING'];
}
else $REQUEST_URI = $_SERVER['REQUEST_URI'];
if(!$sid) $sid = session_id();
session_id($sid);
$REMOTE_ADDR = getIpAddress();
if(!isset($_SESSION['ssip'])) {
	#$ssip = getenv("REMOTE_ADDR");
	$ssip = $REMOTE_ADDR;
	mybb_session_register("ssip");
} 
elseif((!strstr($REQUEST_URI,"actions.php") && $_SESSION['ssip']!=$REMOTE_ADDR)) {
	// Cookie vorhanden, wahrscheinlich schon eingeloggt => nicht weiterleiten, sondern nur eine neue session starten.
	if(isset($_COOKIE['user_id']) && intval($_COOKIE['user_id'])>0 && isset($_COOKIE['user_password']))
	{
		session_unset();
		session_destroy();
		#session_name("sid");
		#session_start();
		#$sid=session_id();
	}
	// Session vollkommen killen..
	else
	{
		session_unset();
		session_destroy();
		header("Location: ".basename($REQUEST_URI)."");
		exit;
	}
}
$client_ip = ( !empty($HTTP_SERVER_VARS['REMOTE_ADDR']) ) ? $HTTP_SERVER_VARS['REMOTE_ADDR'] : ( ( !empty($HTTP_ENV_VARS['REMOTE_ADDR']) ) ? $HTTP_ENV_VARS['REMOTE_ADDR'] : $REMOTE_ADDR );
$user_ip = encode_ip($client_ip);
$user_ip = decode_ip($user_ip);


$user_id="";
$user_password="";
if(isset($_COOKIE['user_id']) && intval($_COOKIE['user_id'])>0) $user_id = intval($_COOKIE['user_id']);
elseif(isset($_SESSION['user_id']) && intval($_SESSION['user_id'])>0 && !$user_id) $user_id = intval($_SESSION['user_id']);
else $user_id=0;

if(isset($_COOKIE['user_password']) && $_COOKIE['user_password']) $user_password = ($_COOKIE['user_password']);
elseif(isset($_SESSION['user_password']) && $_SESSION['user_password'] && !$user_password) $user_password = ($_SESSION['user_password']);
else $user_password="";



// $user_id & $user_password verifizieren...
if($user_id && $user_password && check_userdata($user_id,$user_password)) {
$SQL = "SELECT * FROM login2_users WHERE ID = '$user_id';";    
$Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  $userdata=mysql_fetch_array($RS,MYSQL_ASSOC);
        if($userdata['blocked']) $blocked = 1;
		else $blocked = 0;
        $username = $userdata['username'];
        $user_group = $userdata['group'];
        $old_time = $userdata['lastvisit'];
        $new_time = $userdata['lastactivity'];
        $session_link = $userdata['session_link'];
        $hide_signature = $userdata['signature'];
        $hide_userpic = $userdata['Avatar'];
        $login=1;
     
        if($userdata['style_set']) $styleid = $userdata['style_set'];
        if($new_time < (time()-900)) {
         $old_time = $new_time;
         $new_time = time();
        }
        else {
         $new_time = time();
        }
}
else {
	$user_id=0;
	if(isset($_SESSION['old_time'])) $old_time = intval($_SESSION['old_time']);
	else $old_time = "";
	if(!$old_time) $old_time = time();
	$new_time = time();

	mybb_session_register("old_time");
	mybb_session_register("new_time");
  $username="Gast";
	$session_link = 0;
	$umaxposts = 0;
	$hide_signature = 0;
	$hide_userpic = 0;
	$prunedays = 0;
	$u_bbcode = 1;
	$blocked=0;
  $login=0;
  $level=0;
  $user_group=1;
  $Admincp="";          
} 
if(isset($_SESSION['url_ak'])) $url_jump = $_SESSION['url_ak'];
else $url_jump = "";
if(!$url_jump) $url_jump = urlencode(basename($REQUEST_URI));
if(!strstr($REQUEST_URI,"actions.php") && !strstr($REQUEST_URI,"register.php") && !strstr($REQUEST_URI,"misc.php")) $url_ak = urlencode($REQUEST_URI);
else $url_ak = $_SESSION['url_ak'];
mybb_session_register("url_ak");
mybb_session_register("url_jump");

$session = "";
$session2 = "";
if(!$session_link) {
	$session = "&sid=".$sid;
	$session2 = "?sid=".$sid;
}
/*--------------------------------------------------------------
Aus laden aller Wichtigen Vasriablen aus der jeweiligen Datenbank
----------------------------------------------------------------*/
  $SQL="Select * from style";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  $zeile=mysql_fetch_array($RS,MYSQL_ASSOC);
  $logo=$zeile["logo"];
  $bgcolor=$zeile["hintergrund"];
  $forenfarbe=$zeile["forumfarbe"];
  $headerfarbe=$zeile["header"];
  $imagefolder=$zeile["imagefolder"];
  $tplfolder="./templates/";
  $css=$zeile["css"];
  

  $SQL="SELECT * FROM `group` WHERE `groupid` = '$user_group';";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  $group=mysql_fetch_array($RS,MYSQL_ASSOC);


  if ($group['can_use_acp']==1)
  {
     $Admincp="&nbsp;<a href='acp/index.php' target='_blank'> Admin CP</a> &nbsp;&nbsp;&nbsp;|";
  }
  else
  { $Admincp="";    }
  
$SQL="Select * from forum";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  $zeile=mysql_fetch_array($RS,MYSQL_ASSOC);
  $forumname=$zeile["name"];
  $version=$zeile["Version"];
  $adminmail=$zeile["adminmail"];
  $localdir=$zeile["localdir"];


if ($login==1)
{
# login anfang
$SQL = "SELECT * FROM login2_users WHERE username = '$username';";    
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  $zeile=mysql_fetch_array($RS,MYSQL_ASSOC);
  $Avatar="<img src=" . $zeile["Avatar"] . ">";
  $level=$zeile["level"];
}

# login ende
if ($u_action=='forum')
{
$SQL="Select * from board WHERE ID='$u_boardid'";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  $zeile=mysql_fetch_array($RS,MYSQL_ASSOC);
  $boardname=$zeile["name"];
}
if ($u_action=='thread')
{
$SQL="Select * from board WHERE ID='$u_boardid'";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  $zeile=mysql_fetch_array($RS,MYSQL_ASSOC);
  $boardname=$zeile["name"];
$SQL="Select * from thread WHERE ID='$u_threadid'";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  $zeile=mysql_fetch_array($RS,MYSQL_ASSOC);
  $threadname=$zeile["name"];
  $close=$zeile["close"];
}
if ($username!='Gast')
{
$Profil="<a href='profil.php?action='>Profil</a>&nbsp;&nbsp;&nbsp;| <a href=pms.php?action=&step=list>PM's</a>";
$register="";
}
else
{
$Profil="";
$register="<a href='register.php?action=&step=1'>Registrieren</a>&nbsp;&nbsp;&nbsp;|&nbsp;";
}

#--------------Partner--------------
$SQL="Select * from partner;";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  $partner=Null;
  while($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
  $partner.="<a href=".$zeile["P_link"]." target=_blank><img src=".$zeile["P_banner"]." border=0></a><br>";
  }




$session_post = "<INPUT TYPE=\"HIDDEN\" NAME=\"sid\" VALUE=\"$sid\">";
if($session) $session_post = "<input type=\"hidden\" name=\"sid\" value=\"$sid\">";


useronline($user_id);
?>   