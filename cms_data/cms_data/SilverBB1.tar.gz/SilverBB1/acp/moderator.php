<?
include "dbconnect.inc.php";
 
import_request_variables('gp','u_');

$ausgabe ="<form action='moderator.php?step=2&boardid=$u_boardid&action=$u_action' method=Post>";
$ausgabe.="<SELECT NAME='userid'>";
$SQL = "SELECT * FROM login2_users;";    
  Conn();
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  while ($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
    $name=$zeile["username"];
    $userid=$zeile["ID"];
    $ausgabe.= "<option value='$userid'>$name</option";
  }
  mysql_free_result($RS);
  $ausgabe.= "</select><input type='submit' value=OK>";
  $ausgabe.= "</form>";
  
  echo $ausgabe;
  DisConn();
#------------------------------
if ($u_action="add") 
if ($u_step=='2')
{
import_request_variables('p','frm_');
	  $strSQL="INSERT INTO moderator " . 
	      "(user_id,boardid)" . 
		  " VALUES('$frm_userid','$u_boardid');";
      	  Conn();
	  mysql_select_db($DB,$Conn);
        fehler();
	  mysql_query($strSQL);
    fehler();
    echo mysql_affected_rows() . " Moderator hinzugef&uuml;gt!";
    fehler();
    DisConn();
}
else if ($u_action="del")
if ($u_step=='2')
{
import_request_variables('p','frm_');
	  $strSQL="INSERT INTO moderator " . 
	      "(user_id,boardid)" . 
		  " VALUES('$frm_userid','$u_boardid');";
      	  Conn();
	  mysql_select_db($DB,$Conn);
        fehler();
	  mysql_query($strSQL);
    fehler();
    echo mysql_affected_rows() . " Moderator hinzugef&uuml;gt!";
    fehler();
    DisConn();
}
?> 	  
