<?php
$u_action=$_GET["action"];
include "dbconnect.inc.php";
include "header.php";

function getfilesfromdir($path){ // returns list of all files in given directory
    $d = dir($path);
    if (!$d) {
        echo "Can't read directory.";
        exit();
    }
    $n = 0;
    while($entry=$d->read()) {
        if ($entry != "." && $entry != "..") {
            if(is_file($path.'/'.$entry)) {$qfil[]=$path."/".$entry;}
            ++$n;
        }
    }
    $er=@sort($qfil);
    $d->close();
    return $qfil;
}

if(isset($_GET['action']))
{
  switch($_GET['action'])
  {
    case "view":
      $template_folder_cat="";
      $SQL=$dbconn->query("SELECT * FROM style");
      while($result=$dbconn->fetch_array($SQL))
      {
        eval("\$template_folder_cat.=\"".template("template_folder_cat")."\";");
      }
      eval("echo(\"".template("template_folder")."\");");
    break;
    case "tplview":
      $link="./../".$_GET["folder"];
      $tpls=getfilesfromdir($link);   
      $template_cat="";
      foreach($tpls as $value)
      {
        $value=str_replace($link."/","",$value); 
        eval("\$template_cat.=\"".template("template_cat")."\";");
      }
      eval("echo(\"".template("template_view")."\");");
    break;
    case "edit":
    $inhalt="";
      $lines=file("./../".$_GET["folder"].$_GET["tpl"]);
      foreach ($lines as $line_num => $line) {
        $inhalt.=htmlspecialchars($line);
      }
      echo "<textarea cols=\"100\" rows=\"40\">$inhalt</textarea>";
    break;
  }
}
elseif(isset($_POST['action']))
{
  switch ($_POST["action"])
  {
    case "edit":
      
  }
}

?>