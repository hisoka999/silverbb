<?php
import_request_variables('gp','u_');
include "dbconnect.inc.php"; 
include "header.php";
echo "<html>
<body><table>";
 $users=$dbconn->queryone("SELECT count(*) FROM login2_users");
echo "<tr><td>Benutzer Anzahl: $users</td></tr>";
 $non_activ=$dbconn->queryone("SELECT count(*) FROM login2_users WHERE active!=1");
 
echo "<tr><td>Nicht freigeschaltete User: $non_activ</td></tr>";
echo "</table>";

?>
</body>
</html> 	  
