<?php
echo "<form action='hash.php?step=2' method='Post' name='genhash' id='genhash'>" .
     "<input class='textfeld' type='text' name='hash' id='hash'><br>" .
     "<input type='submit' name='Submit' value='Eintrag speichern'></form>";
import_request_variables('gp','u_');
if ($u_step==2)
{
import_request_variables('p','f_');
$hash = md5($f_hash);
print "Der Hash ist $hash<br>";
echo "<p>$hash</p>";
}
?>