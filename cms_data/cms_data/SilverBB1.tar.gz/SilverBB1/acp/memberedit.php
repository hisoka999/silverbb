<? 
include "dbconnect.inc.php";
import_request_variables('gp','url_');
$SQL="Select news.Name, news.inhalt," . 
      "news.link, news.ID From news";
Conn();
	  mysql_select_db($DB,$Conn);
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  while($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
  $id=$zeile["ID"];
  if ($id==$url_id)
  {
    $inhalt=$zeile["inhalt"];
    $Name=$zeile["Name"];
    $link=$zeile["link"];
    } 
}
mysql_free_result($RS);
DisConn();
?>
<form action="newsadd.php?step=2" method="post" name="GbuchDaten" id="GbuchDaten">
  <table width="100%" border="0" cellspacing="5">
    <tr> 
      <td>News Titel:</td>
      <td><input class="textfeld" name="Name" type="text" value="<? echo "$Name"?>" id="Name" size="30" maxlength="30"></td>
    </tr>
    <tr> 
      <td height="23">Inhalt:</td>
      <td><textarea class="textfeld" name="inhalt"  id="inhalt" cols="60" rows="10"><?echo "$inhalt"?></textarea></td>
    </tr>
    <tr>
    <tr> 
      <td height="23">Link:</td>
      <td><input class="textfeld" value="<?echo "$link"?>" name="link" type="text" id="link" size="40" maxlength="40"></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td><input type="submit" name="Submit" value="Eintrag speichern"></td>
      <td>&nbsp;</td>
    </tr>
  </table>
  Die Daten m&uuml;ssen exakt eingegeben werden, bitte achten sie also auf die Gro&szlig;- und Kleinschreibung
<? if ($url_step==2)
{
include "dbconnect.inc.php";
	  //importieren der mit POST gesendeten Daten
      import_request_variables('p','frm_');
	  $strSQL="update news Set Name=$Name inhalt=$inhalt link=$link Where ID=$id";

	  Conn();
	  mysql_select_db($DB,$Conn);
	  
	  mysql_query($strSQL);
	  

	  echo mysql_affected_rows() . " Datensatz/Datens�tze eingef�gt!";
	  
      DisConn();
} 
?>
<table>
<tr>
<td>
</td>
</tr>
</table>
