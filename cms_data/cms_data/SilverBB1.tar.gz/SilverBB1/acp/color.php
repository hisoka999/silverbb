<html>
<head><title>t</title></head>
<body>
<?php
function getZelle($Rot,$Gruen,$Blau,$Text='&nbsp;')
{
return "<td style='background-color:rgb(" . "$Rot,$Gruen,$Blau)'>$Text</td>";
}
?>
<table border="0" width="100%" cellspacing="0">
<?php
$I=0;
$strZeile="";
for ($R=255;$R>=0;$R-=10)
{
for ($G=255;$G>=0;$G-=10)
{
for ($B=255;$B>=0;$B-=10)
{
$I++;
if ($I%20==0)
{
$strZeile="<tr>" . $strZeile . "</tr>";
echo $strZeile;
$strZeile="";
}
$strZeile= $strZeile . getZelle($R,$G,$B, dechex($R) . dechex($G) . dechex($B));
}
}
}
$strZeile="<tr>" . $strZeile . "</tr>";
echo $strZeile;
?>
</table>
</body>
</html>