<? 
echo "<a href=color.php target=_blank>Farben</a><br>";
include "dbconnect.inc.php";
if(isset($_GET["step"])) $url_step=$_GET["step"];
else $url_step=1;
if ($url_step==1)
{
  $SQL="Select * from style where style_id=1";
  
  Conn();
	mysql_select_db($DB,$Conn);

  $RS=mysql_query($SQL,$Conn);
  
  //Daten ausgeben
  $style=mysql_fetch_array($RS,MYSQL_ASSOC);
  
  mysql_free_result($RS);
  
  DisConn();



echo "<form action=styleedit.php?step=2&style_id=".$style["style_id"]." method=post name=GbuchDaten id=GbuchDaten>
  <table width=100% border=0 cellspacing=5>
    <tr> 
      <td>Stylename:</td>
      <td><input class=textfeld name=Name type=text value=".$style["name"]." id=Name size=30 maxlength=30></td>
    </tr>
    <tr> 
      <td height=23>Imageordner:</td>
      <td><input class=textfeld name=imagefolder type=text value=".$style["imagefolder"]." id=pw size=30 maxlength=30></td>
    </tr>
    <tr>
    <tr> 
      <td height=23>Templateordner:</td>
      <td><input class=textfeld value=$style[tplfolder] name=tplfolder type=text id=active size=40 maxlength=40></td>
    </tr>
    <tr>
    <td height=23>Logo:</td>
      <td><input class=textfeld value=$style[logo] name=logo type=text id=active size=40 maxlength=40></td>
    </tr>
    <tr>
    <td height=23>Headerfarbe:</td>
      <td><input class=textfeld value=$style[header] name=header type=text id=active size=40 maxlength=40></td>
    </tr>
    <tr>
      <td height=23>Hintergrundfarbe:</td>
      <td><input class=textfeld value=$style[hintergrund] name=hintergrund type=text id=active size=40 maxlength=40></td>
    </tr>
    <tr>
          <td height=23>Forumfarbe:</td>
      <td><input class=textfeld value=$style[forumfarbe] name=forumfarbe type=text id=active size=40 maxlength=40></td>
    </tr> 
        <tr> 
      <td height=23>CSS:</td>
      <td><textarea class=textfeld name=css  id=inhalt cols=60 rows=10>$style[css]</textarea></td>
    </tr>   
    <tr>
        <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td><input type=submit name=Submit value=Bearbeiten></td>
      <td>&nbsp;</td>
    </tr>
  </table>
  </form>
  Die Daten m&uuml;ssen exakt eingegeben werden, bitte achten sie also auf die Gro&szlig;- und Kleinschreibung";


}
else if ($url_step==2)
{

	  //importieren der mit POST gesendeten Daten
      import_request_variables('p','frm_');

	  $strSQL="update style Set name='$frm_Name', header='$frm_header', hintergrund='$frm_hintergrund', forumfarbe='$frm_forumfarbe', logo='$frm_logo', imagefolder='$frm_imagefolder', tplfolder='$frm_tplfolder', css='$frm_css' Where style_id='$url_style_id';";

	  Conn();
	  mysql_select_db($DB,$Conn);
fehler();	  
	  mysql_query($strSQL);
	  
fehler();
	  echo mysql_affected_rows() .  "Datensatz/Datens�tze eingef�gt!";
	  fehler();
      DisConn();
} 
?>
<p><a href=admin.php?action=>zur&uuml;ck zum Admin CP</a></p>

