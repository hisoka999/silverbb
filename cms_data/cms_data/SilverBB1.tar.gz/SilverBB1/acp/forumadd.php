<?php
$frm_step="";

import_request_variables('gp','u_');

include "dbconnect.inc.php"; 
include "header.php"; 
if ($u_step!=2)
{
echo "<form action=forumadd.php?step=2&action= method=post>
  <input type=hidden name=step value=2>
  <table width=100% border=0 cellspacing=5>
    <tr> 
      <td>Forum Name:</td>
      <td><input class=textfeld name=Name type=text value='' id=Name size=30 maxlength=30></td>
    </tr>
    <tr> 
      <td height=23>&Uuml;bergeordnetes Forum:</td>
      <td>
      <SELECT NAME=oberboard><option value=0>--keins--</option>";  
     
$SQL="SELECT * FROM board WHERE type='1';";
  Conn();
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  $oberboard="";

  while ($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
    $boardid=$zeile["ID"];
    $boardname=$zeile["name"];
    $oberboard.= "<option value=$boardid>$boardname</option>";
  }
  mysql_free_result($RS);
  DisConn();
  echo $oberboard;
  
echo "</select></td>   
    </tr>
    <tr> 
      <td height=23>Kategorie</td>
      <td><SELECT NAME=kategorie><option value=0>Nein</option><option value=1>Ja</option></select></td>
    </tr>
    <tr> 
      <td height=23>Beschreibung</td>
      <td><textarea name=beschreibung rows=15 cols=35></Textarea></td>
    </tr>
    <tr> 
      <td height=23>Kann Forum sehen</td>
      <td><select name=can_view[] multiple size=4>";
$SQL="SELECT * FROM `group`";
  Conn();
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben

  while ($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
  $groupid=$zeile["groupid"];
  $group_name=$zeile["Name"];
  echo "<option value=$groupid>$group_name</option>";
  }
          
echo    "</select><td>
</tr>
    <tr> 
      <td height=23>Kann im Forum Beitr&auml;ge schreiben</td>
      <td><select name=can_post[] multiple size=4>";
$SQL="SELECT * FROM `group`";
  Conn();
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben

  while ($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
  $groupid=$zeile["groupid"];
  $group_name=$zeile["Name"];
  echo "<option value=$groupid>$group_name</option>";
  }
          
echo    "</select><td>
</tr>
    <tr> 
      <td height=23>Kann Themen erstellen</td>
      <td><select name=can_thread[] multiple size=4>";
$SQL="SELECT * FROM `group`";
  Conn();
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben

  while ($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
  $groupid=$zeile["groupid"];
  $group_name=$zeile["Name"];
  echo "<option value=$groupid>$group_name</option>";
  }
          
echo    "</select><td>
</tr>
<tr>
        <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td><input type=submit name=Submit value=Eintrag speichern></td>
      <td>&nbsp;</td>
    </tr>
  </table>";
  }
import_request_variables('p','frm_'); 
if ($frm_step==2)
{
$groups=_sql("SELECT count(*) as anzahl FROM `group`","anzahl");
$groups=$groups-1;
//for $i=0,$groups
$i=0;
 	  Conn();
	  mysql_select_db($DB,$Conn);          
    $strSQL="INSERT into board (name,type,Beschreibung,parentid,pos)
    Values ('$frm_Name','$frm_kategorie','$frm_beschreibung','$frm_oberboard','1');";
	  mysql_query($strSQL) or die(mysql_error());
    $boardid=_sql("SELECT ID FROM `board` WHERE name='$frm_Name' order by ID asc","ID");
    while ($i<=$groups){
      $groupid=$i+1;
      if (isset($frm_can_view[$i])){ $view=1;
      if (isset($frm_can_thread[$i])) $thread=1;
      else $thread=0;
      if (isset($frm_can_post[$i])) $post=1;
      else $post=0;      
      $strSQL="INSERT into `group2board` (boardid,groupid,can_view,can_thread,can_post) values
          ('$boardid','".$frm_can_view[$i]."','$view','$thread','$post');";
          echo "$strSQL<br>";
  	  mysql_query($strSQL);
      }
      $i++; 
    }
	  echo mysql_affected_rows() . " Datensatz/Datens�tze eingef�gt!";
//	  for $i=1,$frm_can_view
      DisConn();      
      }
?>  
