<?
$i=0;
import_request_variables('gp','u_');
include "dbconnect.inc.php"; 
include "header.php"; 
if ($u_step!=2){
echo "<form action=test.php?step=2&action= method=post>
<select name=can_view[] multiple size=4>";
$SQL="SELECT * FROM `group`";
  Conn();
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben

  while ($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
  $groupid=$zeile["groupid"];
  $group_name=$zeile["Name"];
  echo "<option value=$groupid>$group_name</option>";
 
  }
          
echo    "</select>
      <input type=submit name=Submit value=Eintrag speichern>";

  }
 
if ($u_step==2)
{
import_request_variables('p','frm_');
$groups=_sql("SELECT count(*) as anzahl FROM `group`","anzahl");
$groups=$groups-1;
//for $i=0,$groups


    $boardid=1;
    while ($i<=$groups){
      $groupid=$i+1;
      if (isset($frm_can_view[$i])){ $t=1;

      $strSQL="INSERT into `group2board` (boardid,groupid,can_view) values
          ('$boardid','".$frm_can_view[$i]."','$t');";
          echo "$strSQL<br>\n";
      $i++;
      }	     
    }
}
?>  
