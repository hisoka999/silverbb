<?
function Conn()
{
    global $Conn;
    global $Server;
    global $Benutzer;
    global $Kennwort;
    //$Conn=mysql_connect($Server);
    $Conn=mysql_connect($Server,$Benutzer,$Kennwort);
    };
    
function DisConn()
{ 
  global $Conn;
  mysql_close($Conn);
  };
function getZelle($strWert, $strKlasse)
  {
    $strTemp="";
    if ($strWert==FALSE)
    {
      $strWert="&nbsp;";
    }
    if ($strKlasse==FALSE)
    {
      $strKlasse="";
    }
    else
    {
      $strKlasse=" class=\"$strKlasse\" ";
    }
    $strTemp="\n\t\t\t<td$strKlasse>$strWert</td>\n";
    return $strTemp;
  }        
	function fehler()
	{
		global $mode;
		$strTemp="";
		switch (mysql_errno())
		{
			case 0:
				$strTemp="";
				break;
			case 1046: 
			    $strTemp="Die Datenbank ist " . 
			    "derzeit nicht erreichbar! Das Problem wurde " .
			    "dem Webmaster bereits gemeldet und wird z�gig " . 
			    "behoben.";
				if ($mode=="debug")
				{
					$strTemp=mysql_errno() . ": " . mysql_error();
				}
			    break;			
			case 2005:
				$strTemp="Der Server ist " .
				"derzeit nicht erreichbar! Das Problem wurde " .
				"dem Webmaster bereits gemeldet und wird z�gig " .
				"behoben.";
				if ($mode=="debug")
				{
					$strTemp=mysql_errno() . ": " . mysql_error();
				}				
				break;
			default:
			    $strTemp="Die Seite konnte nicht fehlerfrei aus" .
			    "gef�hrt werden. Bitte versuchen Sie es " . 
				"sp�ter noch mal!";
				if ($mode=="debug")
				{
					$strTemp=mysql_errno() . ": " . mysql_error();
				}				
				break;						
		}
			if ($strTemp!="")
			{
				echo "<p style='color:red;font-style:bold'>$strTemp</p>";
			}		
	}


function encode_ip($dotquad_ip)
{
	$ip_sep = explode('.', $dotquad_ip);
	return sprintf('%02x%02x%02x%02x', $ip_sep[0], $ip_sep[1], $ip_sep[2], $ip_sep[3]);
}
function decode_ip($int_ip)
{
	$hexipbang = explode('.', chunk_split($int_ip, 2, '.'));
	return hexdec($hexipbang[0]). '.' . hexdec($hexipbang[1]) . '.' . hexdec($hexipbang[2]) . '.' . hexdec($hexipbang[3]);
}
function mybb_session_register($varname)
{
    global $register_globals, $HTTP_SESSION_VARS, ${$varname};
    $done = false;
    if($register_globals)
    {
        $done = session_register("$varname"); 
    }
    else
    {
        if($HTTP_SESSION_VARS[$varname] = ${$varname}) $done=true;
		if($_SESSION[$varname] =${$varname}) $done=true;
    }
    return $done; 
}
function mybb_session_unregister($varname)
{
	global $register_globals, $HTTP_SESSION_VARS, ${$varname};
	$done = false;
	if($register_globals)
	{
		$done = session_unregister("$varname");
	}
	else
	{
		unset($HTTP_SESSION_VARS[$varname]);
		unset($_SESSION[$varname]);
		$done=true;
	}
	return $done;
}
function getIpAddress() {
 $REMOTE_ADDR=getenv("REMOTE_ADDR");
 $HTTP_X_FORWARDED_FOR=getenv("HTTP_X_FORWARDED_FOR");
	
 if($HTTP_X_FORWARDED_FOR!="") {
  if(preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $HTTP_X_FORWARDED_FOR, $ip_match)) {
   $private_ip_list = array("/^0\./", "/^127\.0\.0\.1/", "/^192\.168\..*/", "/^172\.16\..*/", "/^10..*/", "/^224..*/", "/^240..*/");	
   $REMOTE_ADDR = preg_replace($private_ip_list, $REMOTE_ADDR, $ip_match[1]);	
  }	
 }
 
 if(strlen($REMOTE_ADDR)>16) $REMOTE_ADDR=substr($REMOTE_ADDR, 0, 16);
 return $REMOTE_ADDR;
}
function checkUser($username,$password) {
        global $Server;
        global $DB;
        global $Benutzer;
        global $Kennwort;
        $SQL = "SELECT password FROM login2_users WHERE username='$username';";    
        $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
        mysql_select_db($DB,$Conn);
        //Verbindung zur mysql-Tabelle aufbauen
        $RS=mysql_query($SQL,$Conn);
        //Daten ausgeben
        $result=mysql_fetch_array($RS,MYSQL_ASSOC);
        if(!$result["password"]) return 0;
        elseif($result["password"]==$password) return 2;
        else return 1;
}
function check_userdata($userid,$password) {
        global $Server;
        global $DB;
        global $Benutzer;
        global $Kennwort;
        $SQL = "SELECT COUNT(ID) FROM login2_users WHERE id='$userid' AND password = '".addslashes($password)."' AND active = 1";    
$Conn = mysql_connect($Server, $Benutzer, $Kennwort);
        mysql_select_db($DB,$Conn);
        //Verbindung zur mysql-Tabelle aufbauen
        $RS=mysql_query($SQL,$Conn);
        //Daten ausgeben
        $result=mysql_fetch_array($RS,MYSQL_ASSOC);
	return $result["COUNT(ID)"];        
} 
function rehtmlspecialchars($text) {
 $text = str_replace("&lt;","<",$text);
 $text = str_replace("&gt;",">",$text);	
 $text = str_replace("&quot;","\"",$text);
 $text = str_replace("&amp;","&",$text);
 return $text;
}

function ifelse($expression,$returntrue,$returnfalse="") {
	#if (!$expression) return $returnfalse;
	#else return $returntrue;
	return ($expression ? $returntrue : $returnfalse);
}
function formaturl($url, $title="", $maxwidth=60, $width1=40, $width2=-15) {
 if(!trim($title)) $title=$url;
 if(!preg_match("/[a-z]:\/\//si", $url)) $url = "http://$url";
 if(strlen($title)>$maxwidth && !stristr($title,"[img]")) $title = substr($title,0,$width1)."...".substr($title,$width2);
 return "<a href=\"$url\" target=\"_blank\">".str_replace("\\\"", "\"", $title)."</a>";
}
function formatlist($list, $listtype="") {
 $listtype = ifelse(!trim($listtype), "",  " type=\"$listtype\"");
 $list = str_replace("\\\"","\"",$list);
 if ($listtype) return "<ol$listtype>".str_replace("[*]","<li>", $list)."</ol>";
 else return "<ul>".str_replace("[*]","<li>", $list)."</ul>";
}
function phphighlite($code) {

 #$code = str_replace("\\\"","\"",$code);
 $code = rehtmlspecialchars($code);
 #$code = str_replace("&gt;", ">", $code);
 #$code = str_replace("&lt;", "<", $code);
 #$code = str_replace("&amp;", "&", $code);
 #$code = str_replace('$', '\$', $code);
 #$code = str_replace('\n', '\\\\n', $code);
 #$code = str_replace('\r', '\\\\r', $code);
 #$code = str_replace('\t', '\\\\t', $code);
 #$code = str_replace("<br>", "", $code);
 #$code = str_replace("<br />", "", $code);
 $code = stripslashes($code);
 if(!strpos($code,"<?") && substr($code,0,2)!="<?") $code="<?php\n".trim($code)."\n?>";
 $code = trim($code);
 ob_start();
 $oldlevel=error_reporting(0);
 highlight_string($code);
 error_reporting($oldlevel);
 $buffer = ob_get_contents();
 ob_end_clean();
 #$buffer = str_replace("<br />", "",$buffer);

 #$buffer = str_replace("&quot;", "\"", $buffer);
 #echo nl2br(htmlspecialchars($buffer))."<hr>";
 return "<blockquote><pre><font size=1>php:</font><hr><p>$buffer</p><hr></pre></blockquote>";
}
function formatcodetag($code) {
	#$code = str_replace("<br>","",$code);
	#$code = str_replace("<br />","",$code);
	$code = str_replace("\\\"","\"",$code);
	return "<blockquote><pre><font size=1>code:</font><hr><p>".$code."</p><hr></pre></blockquote>";
}

function nt_wordwrap($text, $width = 75) {
         if($text) return preg_replace("/([^\n\r ?&\.\/<>\"\\-]{".$width."})/i"," \\1\n",$text);
}

function prepare_topic($out) { 
	#return htmlspecialchars(nt_wordwrap(editDBdata($out),40)); 
	return htmlspecialchars(nt_wordwrap($out,45));
}
function editPost($out,$disable_smilies=0) {
	global $bbcode,$html,$smilies,$badwords;
	$nlreplace=substr(md5(uniqid(microtime())),0,6);
	if(!$html) 
	{ 
		#$out = str_replace("&lt;","&amp;lt;",$out);
		#$out = str_replace("&gt;","&amp;gt;",$out);
		#$out = str_replace("<","&lt;",$out);
		#$out = str_replace(">","&gt;",$out);
		$out = htmlspecialchars($out);
  	}
	// <script> ist generell verboten...
	else $out = preg_replace("/<script[^>]*>/i","&lt;script\\1&gt;",$out);
	#$out = str_replace("\r\n",$nlreplace,$out);
	#$out = str_replace($nlreplace,"\r\n",$out);
	if($smilies && !$disable_smilies) $out = smilies($out);
	if($bbcode) $out = prepare_code($out);
	#$out = nl2br($out);
	$out = str_replace("\n","<br />",$out);
	$out = censor($out);
	$out = nt_wordwrap($out);
	return $out;
}

function prepare_code($out) {
 global $searcharray,$replacearray,$DB,$Server,$Benutzer,$Kennwort;
 $phpversionnum = phpversion();

 if(!isset($searcharray) && !isset($replacearray)) {
  $searcharray[]="/\[list=(['\"]?)([^\"']*)\\1](.*)\[\/list((=\\1[^\"']*\\1])|(\]))/esiU";
  $replacearray[]="formatlist('\\3', '\\2')"; 
  $searcharray[]="/\[list](.*)\[\/list\]/esiU";	
  $replacearray[]="formatlist('\\1')"; 
  $searcharray[]="/\[url=(['\"]?)([^\"']*)\\1](.*)\[\/url\]/esiU";
  $replacearray[]="formaturl('\\2','\\3')";
  $searcharray[]="/\[url]([^\"]*)\[\/url\]/esiU";	
  $replacearray[]="formaturl('\\1')";
  $searcharray[]="/\[code](.*)\[\/code\]/esiU";	
  $replacearray[]="formatcodetag('\\1')";
  $searcharray[]="/\[php](.*)\[\/php\]/esiU";	
  $replacearray[]="phphighlite('\\1')";
  $searcharray[]="/\[img]([^\"]*)\[\/img\]/siU";	
  $replacearray[]="<img src=\"\\1\" border=0>"; 
  
  $threeparams = "/\[%s=(['\"]?)([^\"']*),([^\"']*)\\1](.*)\[\/%s\]/siU";
  $twoparams = "/\[%s=(['\"]?)([^\"']*)\\1](.*)\[\/%s\]/siU";
  $oneparam = "/\[%s](.*)\[\/%s\]/siU"; 

  $result = "SELECT bbcodetag,bbcodereplace,params FROM bbcode";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($result,$Conn);
  //Daten ausgeben
  while($row = mysql_fetch_array($RS,MYSQL_ASSOC)) {
   if($row['params']==0) continue;
   if($row['params']==1) $search = sprintf($oneparam, $row['bbcodetag'], $row['bbcodetag']);
   if($row['params']==2) $search = sprintf($twoparams, $row['bbcodetag'], $row['bbcodetag']);
   if($row['params']==3) $search = sprintf($threeparams, $row['bbcodetag'], $row['bbcodetag']);

	for($i=0;$i<7;$i++) { // Verschachtelungstiefe
   $searcharray[] = $search;
   $replacearray[] = $row['bbcodereplace']; }
  } 
 }
 
 if ($phpversionnum<"4.0.5") $bbcode=str_replace("'", "\'", $out);
 $out = preg_replace($searcharray, $replacearray, $out);
 $out = str_replace("\\'", "'", $out);
 return $out;
} 

function _sql($result,$spaltenname){
global $DB,$Server,$Benutzer,$Kennwort;
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($result,$Conn);
  //Daten ausgeben
  $row = mysql_fetch_array($RS,MYSQL_ASSOC);
  return $row[$spaltenname];
}

function useronline($user_id)
{
	global $useronlinelastemptied,$timeout,$rekord,$sid,$REMOTE_ADDR,$DB,$Server,$Benutzer,$Kennwort;
	$deltime = time()-($timeout*60);


	// Registrierter Benutzer .. keine ip
	if($user_id)
	{
  
		$strSQL="REPLACE INTO user_online_table (sid,zeit,ip,userid) VALUES ('$sid','".time()."','','$user_id')";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
	  mysql_select_db($DB,$Conn);
	  mysql_query($strSQL);
		$strSQL="DELETE FROM useronline WHERE userid=$user_id AND sid<>'$sid'";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
	  mysql_select_db($DB,$Conn);
	  mysql_query($strSQL);

	}
	
	// Gast, identifizierung anhand der ip..
	else
	{
		$strSQL="REPLACE INTO user_online_table (sid,zeit,ip,userid) VALUES ('$sid','".time()."','$REMOTE_ADDR','')";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
	  mysql_select_db($DB,$Conn);
	  mysql_query($strSQL);

	}
	
	
	// Wenn die letzte "L�schung" mehr als timeout Minuten zur�ckliegt,
	// ist es Zeit f�r die n�chste ;)
	if((time()-$timeout*60)>$useronlinelastemptied)
	{
		$strSQL="DELETE FROM user_online_table WHERE zeit<'$deltime'";
    $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
	  mysql_select_db($DB,$Conn);
	  mysql_query($strSQL);

/*		$strSQL="UPDATE bb".$n."_config SET useronlinelastemptied='".time()."'";
    $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
	  mysql_select_db($DB,$Conn);
	  mysql_query($strSQL); */

	}
	
	// Useronline Rekord aktualisieren..
//	$user = $db_zugriff->query_first("SELECT COUNT(zeit) as anzahl FROM bb".$n."_user_online_table");
//	if($user['anzahl']>$rekord) $db_zugriff->query("UPDATE bb".$n."_config set rekord='".$user['anzahl']."', rekordtime='".time()."'");
} 
function template ($tpl)
{
    global $tplfolder;
    $filename=$tplfolder."/".$tpl.".html";
	        if(!$tplfolder) $tplfolder = "templates";
			$text = implode("",file($tplfolder."/".$tpl.".html"));

    
    return str_replace("\"","\\\"",$text);
}
function useronline_chat($user_id)
{
	global $useronlinelastemptied,$timeout,$rekord,$sid,$REMOTE_ADDR,$DB,$Server,$Benutzer,$Kennwort;
	$deltime = time()-($timeout*60);


	// Registrierter Benutzer .. keine ip
  $online=_sql("Select userid From chat_online Where userid=$user_id","userid");
	if($user_id!=$online)
	{
  
		$strSQL="REPLACE INTO chat_online (userid,zeit,sid,ip) VALUES ('$user_id','".time()."','$sid','')";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
	  mysql_select_db($DB,$Conn);
	  mysql_query($strSQL);
		$strSQL="DELETE FROM chat_online WHERE userid=$user_id AND sid<>'$sid'";
  $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
	  mysql_select_db($DB,$Conn);
	  mysql_query($strSQL);

	}
  	if((time()-$timeout*60)>$useronlinelastemptied)
	{
		$strSQL="DELETE FROM chat_online WHERE zeit<'$deltime'";
    $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
	  mysql_select_db($DB,$Conn);
	  mysql_query($strSQL);

/*		$strSQL="UPDATE bb".$n."_config SET useronlinelastemptied='".time()."'";
    $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
	  mysql_select_db($DB,$Conn);
	  mysql_query($strSQL); */

	}
}  
?>