<?php
import_request_variables('gp','u_');
include "dbconnect.inc.php"; 
include "header.php"; 
echo "<table>";
Conn();
 $SQL="Select * From board where type=1 order by pos asc";
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  while($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
    $ID=$zeile["ID"];
    $name=$zeile["name"];
    echo  "<tr><td>". $zeile["ID"] ."</TD><td>" . $zeile["name"] . 
          "</td>\n<td>" . $zeile["pos"] .
          "</td>\n<td><a href='boarddel.php?id=$ID'>del</a>" .
          "</td>\n<td><a href='forumedit.php?id=$ID&step=1'>edit</a></td>" . 
          "<td><a href='moderator.php?action=add&boardid=$ID'>Moderator hinzuf&uuml;gen</a></td></tr>";
  Conn();
  $SQL1="Select * From board where parentid=$ID order by pos asc";
  mysql_select_db($DB,$Conn);
  //Verbindung zur mysql-Tabelle aufbauen
  $RS1=mysql_query($SQL1,$Conn);
  //Daten ausgeben
  while($zeile1=mysql_fetch_array($RS1,MYSQL_ASSOC))
  {
    $ID1=$zeile1["ID"];
    $name1=$zeile1["name"];
    echo  "\n<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;". $zeile1["ID"] ."</TD><td>" . $zeile1["name"] . 
          "</td>\n<td>" . $zeile1["pos"] .
          "</td>\n<td><a href='boarddel.php?id=$ID1'>del</a>" .
          "</td>\n<td><a href='forumedit.php?id=$ID1&step=1'>edit</a></td>" . 
          "<td><a href='moderator.php?action=add&boardid=$ID1'>Moderator hinzuf&uuml;gen</a></td></tr>";
    }                   
}
echo "</table>";

mysql_free_result($RS);
DisConn();
?> 	  
