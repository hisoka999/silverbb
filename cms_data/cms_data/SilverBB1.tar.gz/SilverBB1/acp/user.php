<?php 
include "dbconnect.inc.php"; 
include "header.php";
echo "<table>";
Conn();
 $SQL=$dbconn->query("Select login2_users.active, login2_users.username From login2_users");

  while($zeile=$dbconn->fetch_array($SQL))
  {
    $name=$zeile["username"];
    echo  "<tr><td>" . $zeile["username"] . 
          "</td><td>" . $zeile["active"] .
          "</td><td><a href='newsdel.php?name=$name'>del</a>" .
          "</td><td><a href='useredit.php?name=$name&step=1'>edit</a></td></tr>";        
}
echo "</table>";
?> 	  
