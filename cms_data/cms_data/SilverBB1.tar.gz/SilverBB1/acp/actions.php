<?php
include "dbconnect.inc.php";
include "./header.php";

if (isset ($_GET['action']))
	$action1 = $_GET['action'];
elseif (isset ($_POST['action'])) $action1 = $_POST['action'];
if (!isset ($link))
	$link = "";
if (!isset ($ride))
	$ride = "";

if ($action1 == "login") {
	// ############## Login ###############
	$kennwort = md5($_POST['kennwort']);
	$username = htmlspecialchars($_POST['username']);
	$usercheck = checkUser($username, $kennwort);
	if ($usercheck == 2) {
		$SQL = "SELECT * FROM login2_users WHERE username = '$username' AND password = '$kennwort';";
		$Conn = mysql_connect($Server, $Benutzer, $Kennwort);
		mysql_select_db($DB, $Conn);
		//Verbindung zur mysql-Tabelle aufbauen
		$RS = mysql_query($SQL, $Conn);
		//Daten ausgeben
		$userdata = mysql_fetch_array($RS, MYSQL_ASSOC);
		$sid_setting = $userdata["session_link"];
		$user_id = $userdata["ID"];
		$user_password = $kennwort;
		$SQL = "INSERT INTO user_online_table (user_id,username) Values($user_id,$username);";
		$Conn = mysql_connect($Server, $Benutzer, $Kennwort);
		mysql_select_db($DB, $Conn);
		mysql_query($SQL);
		mysql_close($Conn);
		setcookie("user_id", "$user_id", time() + (3600 * 24 * 365));
		setcookie("user_password", "$user_password", time() + (3600 * 24 * 365));
		mybb_session_register("user_id");
		mybb_session_register("user_password");
		/* Session ID mitgeben, falls eingeschaltet.. */
		if (!$session_link) { // SID muss angeh�ngt werden.
			$filename = "";
			$querystring = "";
			@ list ($filename, $querystring) = @ explode("?", $ride);
			if (!$querystring) {
				$ride = $filename . "?sid=" . $sid;
			} else // querystring schon vorhanden => sid= ersetzen.
				{
				if (!stristr($querystring, "sid=")) // sid einfach anh�ngen
					{
					$querystring .= "&sid=" . $sid;
				} else // sid= ersetzen
					{
					$querystring = preg_replace("/sid=[a-zA-Z0-9]*/", "sid=", $querystring);
					$querystring = str_replace("sid=", "sid=$sid", $querystring);
				}
				$ride = $filename . "?" . $querystring;
			}

		}
		// Boardcookies verwenden...
		else {
			#setcookie("user_id", "$user_id", time()+(3600*24*365));
			#setcookie("user_password", "$user_password", time()+(3600*24*365));
		}
	}
	header("Location: index.php?sid=$sid");
}
// ############## Logout ###############
if ($action1 == "logout") {
	$ride = urldecode($url_jump);
	if (!@ session_destroy())
		@ session_unset();
	setcookie("user_id");
	setcookie("user_password");
	if (isset ($_COOKIE['user_id']) && $_COOKIE['user_id'])
		$user_id = $_COOKIE['user_id'];
	elseif (isset ($_POST['user_id']) && $_POST['user_id']) $user_id = $_POST['user_id'];
	elseif (isset ($_GET['user_id']) && $_GET['user_id']) $user_id = $_GET['user_id'];
	else
		$user_id = "";
	$SQL = "DELETE FROM user_online_table WHERE userid='$user_id';";
	$Conn = mysql_connect($Server, $Benutzer, $Kennwort);
	mysql_select_db($DB, $Conn);
	mysql_query($SQL);
	mysql_close($Conn);
	setcookie("cbpassword");
	setcookie("votepoll");
	setcookie("sthreads");
	header("Location: index.php?sid=$sid");
}

exit;
?>    