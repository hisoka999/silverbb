<?php
include "dbconnect.inc.php";
import_request_variables('gp','url_');
if ($url_step!=2)
{
$SQL="Select login2_users.username, login2_users.password," . 
      "login2_users.active, login2_users.group From login2_users";
Conn();
	  mysql_select_db($DB,$Conn);
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  while($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
  $name=$zeile["username"];
  if ($name==$url_name)
  {
    $username=$zeile["username"];
    $active=$zeile["active"];
    $pw=$zeile["password"];
        $group=$zeile["group"];
    } 
}
mysql_free_result($RS);
DisConn();

?>
<form action="useredit.php?step=2&name=<?php echo $url_name ?>" method="post" name="GbuchDaten" id="GbuchDaten">
  <table width="100%" border="0" cellspacing="5">
    <tr> 
      <td>Username:</td>
      <td><input class="textfeld" name="Name" type="text" value="<?php echo "$username"?>" id="Name" size="30" maxlength="30"></td>
    </tr>
    <tr> 
      <td height="23">Passwort:</td>
      <td><input class="textfeld" name="pw" type="text" value="<?php echo "$pw"?>" id="pw" size="30" maxlength="30"></td>
    </tr>
    <tr>
    <tr> 
      <td height="23">Aktiviert:</td>
      <td><input class="textfeld" value="<?php echo "$active"?>" name="active" type="text" id="active" size="40" maxlength="40"></td>
    </tr>
    <tr> 
      <td height="23">Usergruppe:</td>
      <td>
<SELECT NAME=group>
<?php
  $SQL="SELECT * FROM `group` ";
  Conn();
	mysql_select_db($DB,$Conn);
  $RS=mysql_query($SQL,$Conn);
  //Daten ausgeben
  while($zeile=mysql_fetch_array($RS,MYSQL_ASSOC))
  {
  if ($zeile["groupid"]==$group) echo "<option value=".$zeile["groupid"]." selected>".$zeile["Name"]."</option>";
  else echo "<option value=".$zeile["groupid"]." >".$zeile["Name"]."</option>";
  }
?>
</select>
</td>
    </tr>    
    <tr>
        <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td><input type="submit" name="Submit" value="Bearbeiten"></td>
      <td>&nbsp;</td>
    </tr>
  </table>
  Die Daten m&uuml;ssen exakt eingegeben werden, bitte achten sie also auf die Gro&szlig;- und Kleinschreibung
<?php
}

 if ($url_step==2)
{
	  //importieren der mit POST gesendeten Daten
      import_request_variables('p','frm_');

	  $strSQL="update login2_users Set `username`='$frm_Name', `password`='$frm_pw', `active`='$frm_active', `group`=$frm_group Where `username`='$url_name';";

	  Conn();
	  mysql_select_db($DB,$Conn);
fehler();	  
	  mysql_query($strSQL);
	  
fehler();
	  echo mysql_affected_rows() . " Datensatz/Datens�tze eingef�gt!";
	  fehler();
      DisConn();
} 
?>
<a href="main.php?action=">zur&uuml;ck zum Admin CP</a>
<table>
<tr>
<td>
</td>
</tr>
</table>
