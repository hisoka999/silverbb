<?php
class dbconn {
	var $Conn = 0;
	var $DB;
	var $Benutzer;
	var $Kennwort;
	var $Server;
	var $record = array ();
	var $query_id = 0;
	var $queries = 0;

	function Conn() {
		$this->Conn = mysql_connect($this->Server, $this->Benutzer, $this->Kennwort) or die($this->error());
	}

	function query_first($result) {
		global $Conn;
		$RS = $this->query($result);
		$row = mysql_fetch_array($RS, MYSQL_ASSOC) or $this->error($RS);
		return $row;
	}

	function fetch_array($query_id = -1) {
		global $record;
		if ($query_id != -1) {
			$this->query_id = $query_id;
		}
		$record = mysql_fetch_array($this->query_id);
		return $record;
	}

	function query($result) {
		$this->queries++;
		mysql_select_db($this->DB, $this->Conn);
		//Verbindung zur mysql-Tabelle aufbauen
		$RS = mysql_query($result, $this->Conn) or $this->error($result);
		return $RS;
	}

	function queryone($result) {
		global $Conn;
		$RS = $this->query($result);
		$row = mysql_fetch_array($RS, MYSQL_NUM) or $this->error($result);
		return $row[0];
	}

	function error($query = "") {
		$mode = "debug"; //alternative "release"  
		$strTemp = "";
		switch (mysql_errno()) {
			case 0 :
				$strTemp = "";
				break;
			case 1046 :
				$strTemp = "Die Datenbank ist " .
				"derzeit nicht erreichbar! Das Problem wurde " .
				"dem Webmaster bereits gemeldet und wird z�gig " .
				"behoben.";
				if ($mode == "debug") {
					$strTemp = mysql_errno() . ": " . mysql_error();
				}
				break;
			case 2005 :
				$strTemp = "Der Server ist " .
				"derzeit nicht erreichbar! Das Problem wurde " .
				"dem Webmaster bereits gemeldet und wird z�gig " .
				"behoben.";
				if ($mode == "debug") {
					$strTemp = mysql_errno() . ": " . mysql_error();
				}
				break;
			default :
				$strTemp = "Die Seite konnte nicht fehlerfrei aus" .
				"gef�hrt werden. Bitte versuchen Sie es " .
				"sp�ter noch mal!";
				if ($mode == "debug") {
					$strTemp = mysql_errno() . ": " . mysql_error();
					$strTemp .= "<br />Abfrage: " . $query;
				}
				break;
		}
		if ($strTemp != "") {
			echo "<p style='color:red;font-style:bold'>$strTemp</p>";
		}
	}
}
?>