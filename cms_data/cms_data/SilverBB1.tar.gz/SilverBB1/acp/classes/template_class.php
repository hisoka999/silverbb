<?php
class template {

	function strip_quote_slashes($text) {
		$text = str_replace('\\"', '"', $text);
		return $text;
	}
  
	function prepare_text($text,$php=1) {
		$text = str_replace("\\'", "'", $text);
		$text = str_replace('\\\\', '\\', $text);
		if ($php == 1) $text = str_replace('\"', '"', $text); // fr php
		$text = preg_replace('!\$([a-z0-9]+)([a-z0-9_]+)!si', '$GLOBALS[\'\1\2\']', $text);
		$text = preg_replace('!(.*)\[([^\']*)\](.*)!Uis', '\1[\'\2\']\3', $text);
		return $text;
	}
  
	function compile($text) {
		$text = str_replace('\\', '\\\\', $text);
		$text = str_replace("'", "\\'", $text);
		$text = str_replace("\t", '', $text); 

		$search[]  = '!/\*(.*)\*/!siU';
		$replace[] = '';

		$search[]  = '!{if(\(| +)(.*)}!seiU';
		$replace[] = "'\';\nif ('.\$this->prepare_text('\\2').') {\n\techo \''";
		$search[]  = '!{if(\(| +)(.*)}!seiU';
		$replace[] = "'\';\nif ('.\$this->prepare_text('\\2').') {\n\techo \''";
		$search[]  = '!{if(\(| +)(.*)}!seiU';
		$replace[] = "'\';\nif ('.\$this->prepare_text('\\2').') {\n\techo \''";
	
		$search[]  = '!{else}(.*){/if}!seiU';
		$replace[] = "'\'; } else { echo \''.\$this->strip_quote_slashes('\\1').'{/if}'";
		$search[]  = '!{else}(.*){/if}!seiU';
		$replace[] = "'\'; } else { echo \''.\$this->strip_quote_slashes('\\1').'{/if}'";
		$search[]  = '!{else}(.*){/if}!seiU';
		$replace[] = "'\'; } else { echo \''.\$this->strip_quote_slashes('\\1').'{/if}'";
			
		$search[]  = '!{/if}!siU';
		$replace[] = "'; } echo '";
		$search[]  = '!{/if}!siU';
		$replace[] = "'; } echo '";
		$search[]  = '!{/if}!siU';
		$replace[] = "'; } echo '";

		// {php}...{/php}
		$search[]  = '!{php}(.*){/php}!seiU';
		$replace[] = "'\';\n'.\$this->prepare_text('\\1',1).'\necho \''";

		// {$bar} or {foo($bar)}
		$search[]  = '!{([^\n\r\t]*)}!seiU';
		$replace[] = "'\'.('.\$this->prepare_text('\\1').').\''";
    					
		$text = preg_replace($search, $replace, $text);
		return $text;
	}
}
?>