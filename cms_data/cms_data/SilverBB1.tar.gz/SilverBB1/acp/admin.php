<?php
import_request_variables('gp','u_');
include "dbconnect.inc.php"; 
include "header.php";
if ($login==1 and $user_group==2)
{
eval ("\$frameset= \"".template("frameset")."\";");
}
else
{
eval ("\$frameset= \"".template("login")."\";");
}
echo $frameset;
?>

