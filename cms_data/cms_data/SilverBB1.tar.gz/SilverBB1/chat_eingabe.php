<?php
include "funktions.php";
include "acp/data.inc.php";
$u_action="";
include "header.php";
if(isset($_POST['step'])) $step = intval($_POST['step']);
elseif(isset($_GET['step'])) $step = intval($_GET['step']);
else $step=0;
$time=time();
import_request_variables('p','frm_');

$user_id=(int)$_COOKIE["user_id"];
if ($step==2){
    $strSQL="Insert into chat_log (userid,message,Time) values('$user_id','$frm_message','$time');";
        $Conn = mysql_connect($Server, $Benutzer, $Kennwort);
        mysql_select_db($DB,$Conn);
	  mysql_select_db($DB,$Conn);
	  mysql_query($strSQL);
mysql_close($Conn);
}

eval ("\$chat_eingabe= \"".template("chat_eingabe")."\";");
echo $chat_eingabe;
exit;
?>     