<?php
include "dbconnect.inc.php";

include "header.php";
eval ("\$header= \"" . template("header") . "\";");
#### include ende #####
if(isset($_GET["action"]))$action=stripslashes($_GET["action"]);
elseif(isset($_POST["action"]))$action=stripslashes($_POST["action"]);
else $action="";
$profil_index = "";
switch ($action) {
	case "pw" :
		break;
	case "style" :
		$styleid = $dbconn->queryone("SELECT style_set FROM login2_users WHERE ID='$user_id';");
		$sql = $dbconn->query("SELECT style_id,name FROM style");
		$style_option = "<select name=\"style_id\">";
		while ($style = $dbconn->fetch_array($sql)) {
			if ($style["style_id"] == $styleid)
				$style_option .= "<option value=\"" . $style["style_id"] . "\" selected>" . $style["name"] . "</option>";
			else
				$style_option .= "<option value=\"" . $style["style_id"] . "\">" . $style["name"] . "</option>";
		}
		$style_option .= "</select>";
		eval ("\$profil_index= \"" . template("profil_style") . "\";");
		break;
	default :
		$montharray = array (
			"Januar",
			"Februar",
			"M&auml;rz",
			"April",
			"Mai",
			"Juni",
			"Juli",
			"August",
			"September",
			"Ocktober",
			"November",
			"Dezember"
		);

		$user_id =(int) $_COOKIE['user_id'];
		$data=$dbconn->query_first("SELECT * FROM login2_users WHERE ID='$user_id';");
		$avatar=$data["Avatar"];
		$sig=$data["signature"];
		$name=$data["username"];
		$icq=$data["icq"];
		$www=$data["www"];
		$herkunft=$data["herkunft"];
		$birthday = explode("-", $data["birthday"]);
		$day = $birthday[2];
		$month = $birthday[1];
		$years = $birthday[0];
		$days = null;
		$months = null;
		for ($i = 1; $i <= 31; $i++) {
			if ($i == $day)
				$days .= "<option value=\"$i\" selected>$i</option>\n";
			else
				$days .= "<option value=\"$i\">$i</option>\n";
		}
		for ($i = 1; $i <= 12; $i++) {
			if ($i == $month)
				$months .= "<option value=\"$i\" selected>" . $montharray[$i -1] . "</option>\n";
			else
				$months .= "<option value=\"$i\">" . $montharray[$i -1] . "</option>\n";
		}
		if ($Avatar != NULL)
			$Avatar = "$Avatar";
		else
			$Avatar = "";
		eval ("\$profil_index= \"" . template("profil_usercp") . "\";");
}
eval ("\$footer= \"" . template("footer") . "\";");
eval ("echo(\"" . template("profil") . "\");");
?>   
