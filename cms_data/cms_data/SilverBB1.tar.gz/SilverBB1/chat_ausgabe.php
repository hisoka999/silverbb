
<body>
<?php

include "dbconnect.inc.php";
include "header.php";
$u_action="";
$user_id=$_COOKIE["user_id"];
$zeit=_sql("Select zeit From chat_online Where userid=$user_id","zeit");
$SQL=$dbconn->query("Select * from chat_log WHERE Time>$zeit ORDER BY Time ASC");
$chat_post="";
while($zeile=$dbconn->fetch_array($SQL))
{
	$username=$dbconn->queryone("Select username From login2_users Where ID=".$zeile["userid"]);
	$time=date("H:i:s",$zeile["Time"]);
	//    echo "<b>$username</b> [$time]:". $zeile["message"] ."<br />";
	$code=$zeile["message"];
	$zeile["message"]=prepare_code($code);
	eval ("\$chat_post.= \"".template("chat_post")."\";");
}
echo $chat_post;

?>
</body>
<head>
<script>
  
  setInterval('window.document.location.reload()',5000);
  </script>
</head>
