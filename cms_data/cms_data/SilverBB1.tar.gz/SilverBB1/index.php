<?php
/**
 * @author $LastChangedBy: stefan $
 * @copyright &copy; 2007 by www.silver-boards.de
 * @version 0.5
 * @date $LastChangedDate: 2007-11-18 19:28:11 +0100 (So, 18 Nov 2007) $ 
 * @Rev $LastChangedRevision: 21 $ 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */
$start_time=microtime();
include "dbconnect.inc.php";

$board = "";
include "header.php";
eval ("\$header= \"" . template("header") . "\";");
#----Login-----------------
if ($login != 1)
	eval ("\$tpl_login= \"" . template("login") . "\";");
else {
	$newpm = $dbconn->queryone("SELECT count(*) as Anzahl FROM pms Where `read`='0' and `ziel_id`=$user_id;");
	$allpm = $dbconn->queryone("SELECT count(*) as Anzahl FROM pms Where ziel_id=$user_id;");
	$zeit = date("F j, Y, g:i a");
	eval ("\$tpl_login= \"" . template("login_end") . "\";");
}

#-------- Foren----------- 
$SQL = $dbconn->query("Select * from board WHERE `parentid`=0 ORDER BY pos asc, ID asc");
while ($zeile = $dbconn->fetch_array($SQL)) {
	$forum = "";
	$parentid = $zeile["ID"];
	eval ("\$board_header= \"" . template("board_header") . "\";");
	$boardid1 = $zeile["ID"];
	eval ("\$board_catbit= \"" . template("board_catbit") . "\";");
	
	
	$SQL1 = $dbconn->query("Select * from board WHERE type = 0 and parentid = $parentid ORDER BY pos asc");
	while ($boardsort = $dbconn->fetch_array($SQL1)) {
		$boardbeschreibung = $boardsort["Beschreibung"];
		$boardid = $boardsort["ID"];
		if ($boardbeschreibung != null)
			$boardbeschreibung = "<br />$boardbeschreibung";
		#########################################
		#------------- Mod Abfrage --------------
		#########################################        
		$SQL2 = $dbconn->query("SELECT * FROM moderator WHERE boardid=$boardid;");
		$moderator = "";
		while ($mod = $dbconn->fetch_array($SQL2)) {
			if ($moderator != null)
				$moderator .= ",&nbsp;";
			$ID = $mod["user_id"];
			$yname = $dbconn->query_first("SELECT * FROM login2_users WHERE ID=$ID;");
			$modname = "<a href=\"showuser.php?userid=$ID\">" . $yname["username"] . "</a>";
			$moderator .= " " . $modname;
		}
		if ($moderator != null)
			$moderator = "<br><font size=2>Moderatoren: $moderator</font>";
		// count all posts in this board
		$posts = $dbconn->queryone("SELECT COUNT(ID) as anzahl FROM posts WHERE boardid=$boardid");
		#---------Themen-------------------
		$themen = $dbconn->query_first("SELECT count(id)as Anzahl FROM thread WHERE boardid=$boardid;");
		#-----------------------------------
		#--------- Last Post----------------
		$postdatum = NULL;
		$postautor = NULL;
		$lastpost1 = NULL;
		$myname = $dbconn->query_first("SELECT p.ID as postid,p.Titel,t.ID as threadid,t.Name threadname ,p.Datum,t.Datum
				        FROM posts p LEFT JOIN thread t ON p.threadid = t.ID 
				        Where t.boardid=$boardid ORDER BY p.Datum DESC;");
		if ($myname) {
			$threadname = $myname["threadname"];
			$threadid = $myname["threadid"];
			$postid = $myname["postid"];
			$lastpost = $dbconn->query_first("SELECT Autor,Datum FROM posts WHERE ID=".intval($postid));
			$postdatum = strftime("%H:%M:%S %d.%m.%Y", $lastpost["Datum"]);
			if($lastpost["Autor"])
			$autor = $dbconn->queryone("SELECT username FROM login2_users WHERE ID=" . intval($lastpost["Autor"]));
			else $autor ="Gast";
			$postautor = "<a href=showuser.php?userid=" . $lastpost["Autor"] . "&action=>" . $autor . "</a>";
			$lastpost = "<td bgcolor='$forenfarbe' class=tabelle><font size=2><a href=thread.php?boardid=$boardid&threadid=$threadid&action=thread>$threadname</a>" .
			"<br> Erstellt am <b>$postdatum</b> von <b>$postautor</b></font></td>";
		} else {
			$lastpost = "<td bgcolor='$forenfarbe' class=tabelle align=\"center\">keine Beitr&auml;ge vorhanden</td>";
		}
		$test["anzahl"] = 0;
		//$old_time1= strftime("%Y-%m-%d %H:%M:%S",$old_time);
		$test = $dbconn->queryone("SELECT count(*) as anzahl FROM `posts` WHERE `boardid`= $boardid and `Datum` >=  $old_time and Autor not like '$username'");
		if ($test == 0)
			$folder = "<img src=\"{$imagefolder}/folder_big.gif\">";
		else
			$folder = "<img src=\"{$imagefolder}/folder_new_big.gif\">";

		$can_see_forum = $dbconn->queryone("SELECT `can_view` FROM `group2board` WHERE `boardid` = $boardid AND `groupid` = $user_group", "can_view");
		//      $test[$boardid]=$boardid;       
		if ($can_see_forum == 1)
			eval ("\$forum.= \"" . template("forum") . "\";");
	}
	$can_see_board = $dbconn->queryone("SELECT `can_view` FROM `group2board` WHERE `boardid` = $boardid1 AND `groupid` = $user_group", "can_view");
	if ($can_see_board == 1)
		eval ("\$board.= \"" . template("board") . "\";");
}
#########################################
#---------------WIO?--------------------
#########################################
$Weristonline = "";
$SQL = $dbconn->query("SELECT c.userid as userid, l.username as username FROM user_online_table c LEFT JOIN login2_users l ON c.userid=l.ID WHERE c.userid>0 ;");
while ($zeile = $dbconn->fetch_array($SQL)) {
	$ID = $zeile["userid"];
	$name=$zeile["username"];
	
	$Weristonline .= "<a href=\"showuser.php?userid=$ID&action=\">$name</a>,&nbsp;";

}
#########################################
#---------------WIO - Chat?--------------------
#########################################
$Weristonline_chat = "";
$onuser_chat = 0;
$SQL = $dbconn->query("SELECT c.userid as userid, l.username as username 
                        FROM chat_online c 
                        LEFT JOIN login2_users l ON c.userid=l.ID 
                        WHERE c.ip='' and c.userid>0 ;");
while ($zeile = $dbconn->fetch_array($SQL)) {
	$ID = $zeile["userid"];
	//      $name=$zeile["username"];
	$name = $zeile["username"];
	$Weristonline_chat .= "<a href=showuser.php?userid=$ID&action=>$name</a>,&nbsp;";
	$onuser_chat++;

}
#---------------------------------------------------
$user = $dbconn->queryone("Select count(*) from login2_users");

#########################################
#-------------Statistik------------------
#########################################
$zeile = $dbconn->query_first("SELECT count(*) as onuser FROM user_online_table WHERE userid>0");
$ongast = 0;
$onuser = $zeile["onuser"];
$ongast = $dbconn->queryone("SELECT count(*) as onuser FROM user_online_table WHERE userid=0");
$threads = $dbconn->queryone("SELECT count(*) as threadcount FROM thread");
$posts = $dbconn->queryone("SELECT count(*) as postcount FROM posts");
#---- Posts per day----#
$installdate=$dbconn->queryone("SELECT installdate FROM forum");
$onlinetime = explode(".", strftime("%d.%m.%Y", $installdate));

$days = 365 - strftime("%j", $installdate);
$years = date("Y") - strftime("%Y", $installdate);
while ($years != 0 and $years != 1) {
	$days += 365;
	$years--;
}
if ($years == 1)
	$days += date("z");
$postsperday = round($posts / $days, 2);
#----//end// Posts per day----#
###############################
#----------last user----------#
$last = $dbconn->query_first("SELECT username,ID FROM login2_users WHERE regdate=(SELECT max(regdate) FROM login2_users)");
$lastuserid=$last["ID"];
$lastuser=$last["username"];
#----//end// last user--------#
eval ("\$statistik= \"" . template("statistik") . "\";");
eval ("\$footer= \"" . template("footer") . "\";");
eval ("echo(\"" . template("index") . "\");");
?>