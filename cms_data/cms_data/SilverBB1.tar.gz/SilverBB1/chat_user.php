<?php
include "dbconnect.inc.php";
include "header.php";
$user_id=$_COOKIE["user_id"];
useronline_chat($user_id);
$u_action="";
$SQL=$dbconn->query("Select * from chat_online");

$user="";
while($zeile=$dbconn->fetch_array($SQL))
{
	$username=_sql("Select username From login2_users Where ID=".$zeile["userid"],"username");
	$user.= "<b>$username</b><br>";
}
echo $user;
?>
<script>
  
  setInterval('window.document.location.reload()',10000);
  </script>
