<?php
$time_start = microtime(1);
include "dbconnect.inc.php";
$u_action="";
$board="";
include "header.php";
eval ("\$header= \"".template("header")."\";");
#----Login-----------------
if ($login!=1)eval ("\$tpl_login= \"".template("login")."\";");
else{
$user_id=$_COOKIE['user_id'];
$newpm=_sql("SELECT count(*) as Anzahl FROM pms Where `read`='0' and `ziel_id`=$user_id;","Anzahl");
$allpm=_sql("SELECT count(*) as Anzahl FROM pms Where ziel_id=$user_id;","Anzahl");
$zeit=date("F j, Y, g:i a");
eval ("\$tpl_login= \"".template("login_end")."\";");
}

###board structure####
$SQL=$dbconn->query("SELECT * FROM board ORDER BY parentid ASC,pos ASC;");
while ($row=$dbconn->fetch_array($SQL)){
echo $row["name"]."<br>";
}
?>