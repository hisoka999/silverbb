<?php
include "dbconnect.inc.php";

include "header.php";
eval ("\$header= \"" . template("header") . "\";");
# Tabelllen anfang
$SQL1 = $dbconn->query("Select * FROM `group` WHERE `team_page` =1");
$team_group="";
while ($zeile1 = $dbconn->fetch_array($SQL1)) {
	$group_id = $zeile1["groupid"];
	$group_name = $zeile1["Name"];

	$SQL = $dbconn->query("Select * FROM `login2_users` WHERE `group` =$group_id");

	$pos = 0;
	$boardid = "";
	$threadid = "";
	$team_admin = "";
	while ($zeile = $dbconn->fetch_array($SQL)) {
		$_username = $zeile["username"];
		
		$posts = $dbconn->queryone("SELECT count(*) FROM posts WHERE Autor=" . $zeile["ID"]);
		$pos++;
		eval ("\$team_admin.= \"" . template("team_admin") . "\";");
	}
	if ($pos)
		eval ("\$team_group.= \"" . template("team_group") . "\";");
}

eval ("\$footer= \"" . template("footer") . "\";");
eval ("echo(\"" . template("team_index") . "\");");
?>