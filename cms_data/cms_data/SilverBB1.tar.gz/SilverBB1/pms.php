<?php
/**
 * @author Stefan Lüdtke
 * @copyright &copy; 2007 by www.silver-boards.de
 * @version 0.5
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */
 
include "dbconnect.inc.php";
include "header.php";
eval ("\$header= \"" . template("header") . "\";");
$user_id = $_COOKIE['user_id'];
$pms_list = "";
$pms_read = "";
$pms_send = "";
$pmwrite = "";
$u_step=stripslashes($_GET["step"]);
if ($u_step == "send") {
	import_request_variables('p', 'frm_');
	$userdata = $dbconn->query_first("SELECT * FROM login2_users Where username='".$frm_username."';");
	$ziel_id = $userdata["ID"];
	if ($ziel_id != NULL) {
		$dbconn->query("Insert INTO pms(user_id,ziel_id,Titel,inhalt)
	        values('".$user_id."','".$ziel_id."','".$frm_Name."','".$frm_inhalt."');");
	} else {
		$pms_send = "<p>Der eingegebene Empf&auml;nger war falsch!</p>";
	}
	$pms_send = "<a href=pms.php?action=&step=list>Zur&uuml;ck</a>";
} else
	if ($u_step == "write") {
		eval ("\$pmwrite= \"" . template("pmwrite") . "\";");

	} else
		if ($u_step == "list") {
			$pmwrite = "";
			$user_id =(int) $_COOKIE['user_id'];
			$SQL = $dbconn->query("SELECT * FROM pms Where ziel_id='".$user_id."'");

			$pms_list_view = "";
			while ($zeile = $dbconn->fetch_array($SQL)) {
				$pm_id = $zeile["pm_id"];
				$read = $zeile["read"];
				$Titel = $zeile["Titel"];
				if ($read == 1) {
					$read = "ja";
				} else
					if ($read == 0) {
						$read = "nein";
					}
				$id = $zeile["user_id"];
				$Autor = _sql("SELECT username FROM login2_users WHERE ID=".$id, "username");
				eval ("\$pms_list_view.= \"" . template("pms_list_view") . "\";");
			}
			eval ("\$pms_list= \"" . template("pms_list") . "\";");
		} else
			if ($u_step == "read") {
				$read = 1;
				$pm_id=(int) $_GET["pm_id"];
				$dbconn->query("UPDATE `pms` set `read`='".$read."' WHERE `pm_id`='".$pm_id."';");

				$zeile = $dbconn->query_first("SELECT * FROM pms WHERE pm_id=".$pm_id." and ziel_id=".$user_id.";");
				$pm_id = $zeile["pm_id"];
				$read = $zeile["read"];
				if ($read = 1) {
					$read = "ja";
				} else
					if ($read = 0) {
						$read = "nein";
					}
				$Titel = $zeile["Titel"];
				$id = $zeile["user_id"];
				$Autor =$dbconn->queryone("SELECT username FROM login2_users WHERE ID=".$id);
				$inhalt = $zeile["inhalt"];
				$inhalt = prepare_code($inhalt);
				eval ("\$pms_read= \"" . template("pms_read") . "\";");
			}
eval ("\$footer= \"" . template("footer") . "\";");
eval ("echo(\"" . template("pms_index") . "\");");
?>