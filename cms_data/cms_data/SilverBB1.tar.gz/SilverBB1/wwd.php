<?php
include "dbconnect.inc.php";
include "./header.php";
$wwd_cat = "";
$SQL = $dbconn->query("SELECT * FROM login2_users WHERE lastactivity>=".mktime(0,0,0,date("n"),date("j"),date("Y")));
while ($wwd = $dbconn->fetch_array($SQL)) {
	$date = date('H:i', $wwd['lastactivity']);
	eval ("\$wwd_cat.= \"" . template("wwd_cat") . "\";");
}
eval ("echo( \"" . template("wwd") . "\");");
?> 