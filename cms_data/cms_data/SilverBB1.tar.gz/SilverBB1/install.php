<?php
include "acp/data.inc.php";
include "dbconnect.inc.php";

function installtable($name,$result){
	if(!$result){
		$res="<font color=\"red\">false</font>";
	}else{
		$res="<font color=\"green\">true</font>";
	}
	eval("\$spalte = \"".template("install_table_bit")."\";");
	return $spalte;
}
if (isset ($_POST['step']))
$step = intval($_POST['step']);
elseif (isset ($_GET['step'])) $step = intval($_GET['step']);
else
$step = 0;
if ($step == 0) {
	eval("echo \"".template("install")."\";");

} else
if ($step == 2) {
	if(is_writeable("./acp/data.inc.php")){
		$fp = fopen("./acp/data.inc.php", "w+");

		fwrite($fp, "<?php
						// Hostname oder IP des MySQL-Servers
						\$Server = \"" . str_replace("\"", "\\\\\"", $_POST['dburl']) . "\";
						// Username und Passwort zum einloggen in den Datenbankserver
						\$Benutzer = \"" . str_replace("\"", "\\\\\"", $_POST['dbuser']) . "\";
						\$Kennwort = \"" . str_replace("\"", "\\\\\"", $_POST['dbpw']) . "\";
						// Name der Datenbank
						\$DB = \"" . str_replace("\"", "\\\\\"", $_POST['dbname']) . "\";
						?>");
		fclose($fp);
		$result_text= "<a href='install.php?step=3'>Weiter zu Schritt 3</a>";
		$result="erfolgreich";
	}else{
		$result="fehlgeschlagen";
		$result_text= "Die Datei konnte nicht bearbeitet werden. Bitte bearbeiten sie diese Datei manuell.
		<a href='install.php?step=3'>Weiter zu Schritt 3</a>";
	}
	eval("echo \"".template("install-2")."\";");
} else
if ($step == 3) {
	include "acp/classes/db_conn_class.php";
	$dbconn = New dbconn;
	$dbconn->Server = $Server;
	$dbconn->Benutzer = $Benutzer;
	$dbconn->Kennwort = $Kennwort;
	$dbconn->DB = $DB;
	$dbconn->Conn();
	$strSQL = "CREATE TABLE `board` (
  `ID` bigint(20) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL default '',
  `Beschreibung` text NOT NULL,
  `pos` bigint(20) NOT NULL default '0',
  `type` tinyint(1) NOT NULL default '0',
  `parentid` smallint(3) NOT NULL default '0',
  `min_user_level` char(3) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
);";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("board",$Erg);
	$strSQL = "CREATE TABLE `forum` (
  `name` varchar(30) NOT NULL default '',
  `adminmail` varchar(50) NOT NULL default '',
  `Version` varchar(20) NOT NULL default '0.0.0',
  `localdir` varchar(50) NOT NULL default '',
  `default_style` int(11) NOT NULL default '0',
  `installdate` int(11) NOT NULL default '0'
);";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("forum",$Erg);
    
	$strSQL = "CREATE TABLE `login2_users` (
				  `ID` bigint(20) NOT NULL auto_increment,
				  `username` varchar(20) NOT NULL default '',
				  `vorname` varchar(20) default NULL,
				  `name` varchar(10) default NULL,
				  `password` varchar(32) NOT NULL default '',
				  `active` varchar(20) NOT NULL default '0',
				  `Avatar` varchar(50) NULL default '',
				  `session_link` char(1) default '0',
				  `blocked` smallint(1) default '0',
				  `signature` text NULL,
				  `lastvisit` int(11) default '0',
				  `lastactivity` int(11) default '0',
				  `style_set` int(11) NULL default '0',
				  `email` varchar(50) NOT NULL default '',
				  `group` int(11) NOT NULL default '1',
				  `www` varchar(50) default NULL,
				  `herkunft` varchar(25) default NULL,
				  `icq` int(9) default NULL,
				  `birthday` date NOT NULL default '0000-00-00',
				  `regdate` int(11) NOT NULL default '0',
				  PRIMARY KEY  (`ID`)
				);";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("login2_users",$Erg);
	$strSQL = "CREATE TABLE `moderator` (
												  `user_id` mediumint(9) NOT NULL default '0',
												  `boardid` bigint(20) NOT NULL default '0')";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("moderators",$Erg);
	
	$strSQL = "CREATE TABLE `posts` (
												  `ID` bigint(20) NOT NULL auto_increment,
												  `threadid` bigint(20) NOT NULL default '0',
												  `boardid` bigint(20) NOT NULL default '0',
												  `Titel` varchar(50) NOT NULL default '',
												  `Autor` varchar(20) NOT NULL default '',
												  `Inhalt` text NOT NULL,
												  `Datum` timestamp(14) NOT NULL,
												  PRIMARY KEY  (`ID`))";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("posts",$Erg);
    
	$strSQL = "CREATE TABLE `style` (
												  `style_id` int(11) NOT NULL auto_increment,
												  `name` varchar(10) NOT NULL default '',
												  `logo` varchar(50) NOT NULL default '',
												  `header` varchar(7) NOT NULL default '',
												  `hintergrund` varchar(7) NOT NULL default '',
												  `forumfarbe` varchar(7) NOT NULL default '',
												  `imagefolder` varchar(50) NOT NULL default '',
												  `css` text NOT NULL,
												  `tplfolder` varchar(50) NOT NULL default './templates/',
												  PRIMARY KEY  (`style_id`)
												);";
	$Erg = $dbconn->query($strSQL);
	if ($Erg == true) {
		echo ("<p>Die Tabelle <b>style</b> wurde erzeugt!</p>");
	}
	$strSQL="INSERT INTO `style` (`style_id`, `name`, `logo`, `header`, `hintergrund`, `forumfarbe`, `imagefolder`, `css`, `tplfolder`) VALUES
(1, 'MyStyle', 'images/logo.gif', '#BDBDBD', '#D6D6D6', '#BDBDBD', 'images', '.post\r\n{\r\nbackground-color: #BDBDBD;\r\n}\r\n.postanzeige{\r\n\r\npadding:3px;\r\n\r\n}\r\n.textfeld\r\n{\r\nbackground-color: #FF00FF;\r\nfont-size: 12px;\r\n}\r\n.forumbg\r\n{\r\nborder: 0px;\r\nborder-color:#D6D6D6;\r\nbackground-color: #D6D6D6;\r\n}\r\na:hover\r\n{\r\ncolor: #D7E3FE;\r\ntext-decoration: underline overline;\r\n}\r\na\r\n{\r\ncolor: #000000;\r\ntext-decoration: none;\r\n}\r\n.tableout\r\n{\r\nbackground-color: #D6D6D6;\r\ntext-color: #000000;\r\nlink-color: #000000;\r\n}\r\nbody\r\n{\r\nfont-family: Arial;\r\ncolor: #000000;\r\nfont-size: 10px;\r\n}\r\n.tabelle {\r\nbackground-color: #BDBDBD;\r\n}\r\n.boardname{\r\nfont-size: 12px;\r\n}\r\n.threadautor{\r\nfont-size: 12px;\r\n)\r\n.nav{ \r\ncolor: #FFFFFF;\r\n background-color: #BDBDBD;\r\n border-top: 1px #2D2D2D solid;\r\n}\r\n.tabelle1 {\r\nbackground-color: #c3ebff;\r\n}', './templates/'),
(2, 'new_style', './images/my_style/logo.png', '', '', '', './images/my_style/', '.header{\r\nbackground-image: url(''images/cellpic.gif'');\r\n  border:solid;\r\n  border-width:1px;\r\n  border-color:#000000;\r\n}\r\n.nav{\r\nbackground-image: url(''images/cellpic.gif'');\r\ncolor: #000;\r\n}\r\n.nav a:hover{\r\ncolor: #FFFFFF;\r\n}\r\n.nav a{\r\ncolor: #000000;\r\ntext-decoration: none;\r\n}\r\nbody{\r\nbackground-color: #CCCCCC;\r\n}\r\n.tabelle{\r\nbackground-color: #ECECEC;\r\n  border:solid;\r\n  border-width:1px;\r\n  border-color:#000000;\r\n  color: #000;\r\n}\r\n.tabelle a{\r\n  color:#000;\r\n  text-decoration: none;\r\n}\r\n.tabelle a:hover{\r\n  color: #909090;\r\n}\r\n\r\n.tabelle-header{\r\n  background-color: #909090;\r\n  color: #FFFFFF;\r\n  border:solid;\r\n  border-width:1px;\r\n  border-color:#000000;\r\n}\r\n.tabelle-header a:link{\r\n  color: #FFFFFF;\r\n}\r\n.out{\r\n  background-color: #0090FF;\r\n  width: 600px;\r\n  border:solid;\r\n  border-width:1px; \r\n  border-color:#000000;\r\n}\r\n.forum{\r\nwidth: 95%;\r\n}\r\n.header a{\r\n  color:#000;\r\n  text-decoration: none;\r\n}\r\n.header a:hover{\r\n  color: #909090;\r\n}', './templates/my_style/');";
	$Erg = $dbconn->query($strSQL);
	if ($Erg == true) {
		echo ("<p>styles wurden installiert!</p>");
	}
	$strSQL = "CREATE TABLE `thread` (
						  `ID` bigint(20) NOT NULL auto_increment,
						  `name` varchar(50) NOT NULL default '',
						  `Datum` int(15) default '0',
						  `boardid` bigint(20) NOT NULL default '0',
						  `close` tinyint(1) NOT NULL default '0',
						  `Autor` int(11) NOT NULL,
						  `visits` int(11) NOT NULL default '0',
						  `lastposttime` int(11) NOT NULL default '0',
						  `thread_status` tinyint(4) NOT NULL default '0',
						  PRIMARY KEY  (`ID`)
						);";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("thread",$Erg);
	$strSQL = "CREATE TABLE `user_online_table` (
												  `sid` varchar(32) NOT NULL default '',
												  `zeit` int(10) unsigned NOT NULL default '0',
												  `ip` varchar(15) NOT NULL default '0',
												  `userid` int(10) unsigned NOT NULL default '0',
												  `boardid` int(10) unsigned NOT NULL default '0',
												  `threadid` int(10) unsigned NOT NULL default '0',
												  `wioip` varchar(20) NOT NULL default '',
												  `browser` varchar(100) NOT NULL default '',
												  `location` varchar(250) NOT NULL default '',
												  PRIMARY KEY  (`sid`)
												)";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("user_online_table",$Erg);

	$strSQL = "CREATE TABLE `group` (
										  `groupid` int(11) NOT NULL auto_increment,
										  `Name` varchar(20) NOT NULL default '',
										  `can_write_posts` int(1) NOT NULL default '0',
										  `can_edit_own_posts` int(1) NOT NULL default '0',
										  `can_edit_all_posts` int(1) NOT NULL default '0',
										  `can_delete_posts` int(1) NOT NULL default '0',
										  `can_write_topic` int(1) NOT NULL default '0',
										  `can_delete_topic` int(1) NOT NULL default '0',
										  `can_use_off_board` int(1) NOT NULL default '0',
										  `can_edit_user` int(1) NOT NULL default '0',
										  `can_create_user` int(1) NOT NULL default '0',
										  `can_use_pm` int(1) NOT NULL default '0',
										  `can_create_boards` int(1) NOT NULL default '0',
										  `can_moderate_one` int(1) NOT NULL default '0',
										  `can_moderate_all` int(1) NOT NULL default '0',
										  `can_use_acp` int(1) NOT NULL default '0',
										  `can_clos_topic` int(1) NOT NULL default '0',
										  `team_page` tinyint(1) NOT NULL default '0',
										  PRIMARY KEY  (`groupid`)
										);";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("group",$Erg);
	$strSQL = "INSERT INTO `group` (`groupid`, `Name`, `can_write_posts`, `can_edit_own_posts`, `can_edit_all_posts`, `can_delete_posts`, `can_write_topic`, `can_delete_topic`, `can_use_off_board`, `can_edit_user`, `can_create_user`, `can_use_pm`, `can_create_boards`, `can_moderate_one`, `can_moderate_all`, `can_use_acp`, `can_clos_topic`, `team_page`) VALUES
										(1, 'Gast', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
										(2, 'Administrator', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
										(3, 'Moderator', 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1),
										(4, 'User', 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0),
										(5, 'S-Mod', 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1);";

	$Erg = $dbconn->query($strSQL);
	if ($Erg == true)
	echo ("<p><b>group</b> Tabelle wurde gefüllt</p>");

	$strSQL = "CREATE TABLE `bbcode` (
												  `id` smallint(5) unsigned NOT NULL auto_increment,
												  `bbcodetag` varchar(250) NOT NULL default '',
												  `bbcodereplace` varchar(250) NOT NULL default '',
												  `params` tinyint(1) unsigned NOT NULL default '1',
												  PRIMARY KEY  (`id`)
												);";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("true",$Erg);
	$strSQL = "INSERT INTO `bbcode` (`id`, `bbcodetag`, `bbcodereplace`, `params`) VALUES
(1, 'b', '<b>\\1</b>', 1),
(2, 'i', '<i>\\1</i>', 1),
(3, 'email', '<a href=\"mailto:\\1\">\\1</a>', 1),
(4, 'email', '<a href=\"mailto:\\2\">\\3</a>', 2),
(5, 'size', '<font size=\"\\2\">\\3</font>', 2),
(6, 'quote', '<blockquote><font size=1>Zitat:</font><hr>\\1<hr></blockquote>', 1),
(7, 'u', '<u>\\1</u>', 1),
(8, 'color', '<font color=\"\\2\">\\3</font>', 2),
(9, 'font', '<font face=\"\\2\">\\3</font>', 2),
(10, 'align', '<div align=\"\\2\">\\3</div>', 2),
(11, 'mark', '<span style=\"background-color: \\2\">\\3</span>', 2);";
	$Erg = $dbconn->query($strSQL);

	$strSQL = "CREATE TABLE `pms` (
												  `pm_id` int(11) NOT NULL auto_increment,
												  `user_id` int(11) default NULL,
												  `ziel_id` int(11) default NULL,
												  `Titel` varchar(30) default NULL,
												  `inhalt` text,
												  `read` smallint(1) NOT NULL default '0',
												  `datum` timestamp(14) NOT NULL,
												  PRIMARY KEY  (`pm_id`)
												);";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("pms",$Erg);
	$strSQL = "INSERT INTO `forum` (`name`, `adminmail`, `Version`, `localdir`, `default_style`, `installdate`) VALUES
('Silver-Boards Forum', 'mail@mail.com', '0.4.', '', 1, ".time().");";
	$Erg = $dbconn->query($strSQL);
	$strSQL = "CREATE TABLE `ranks` (
												  `ID` tinyint(4) NOT NULL auto_increment,
												  `name` varchar(20) NOT NULL default '',
												  `posts` bigint(20) NOT NULL default '0',
												  `bild` varchar(50) NOT NULL default '',
												  PRIMARY KEY  (`ID`)
												);";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("ranks",$Erg);
	$strSQL = "INSERT INTO `ranks` (`ID`, `name`, `posts`, `bild`, `groupid`) VALUES
																(1, 'Anf&auml;nger', 0, '{./images/star.gif}', 4),
																(2, 'Noob der etwas weis', 3, '{./images/star.gif}{./images/star.gif}', 4),
																(3, 'Administrator', 0, '{./images/star3.gif}\r\n{./images/star3.gif}\r\n{./images/star3.gif}\r\n{./images/star3.gif}\r\n{./images/star3.gif}', 2),
																(4, 'Moderator', 0, '{./images/star3.gif}\r\n{./images/star3.gif}\r\n{./images/star3.gif}', 3);";
	;

	$strSQL = "CREATE TABLE `partner` (
												  `p_id` bigint(20) NOT NULL auto_increment,
												  `P_name` varchar(20) NOT NULL default '',
												  `P_link` varchar(80) NOT NULL default 'http://',
												  `P_banner` varchar(80) NOT NULL default '',
												  PRIMARY KEY  (`p_id`)
												)";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("partner",$Erg);
    
	$strSQL = "CREATE TABLE `group2board` (
										  `groupid` int(11) NOT NULL default '0',
										  `boardid` int(11) NOT NULL default '0',
										  `can_view` tinyint(1) NOT NULL default '0',
										  `can_thread` tinyint(1) NOT NULL default '0',
										  `can_post` tinyint(1) NOT NULL default '0'" .
	");";

	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("group2board",$Erg);
	$strSQL = "CREATE TABLE `smilies` (
								  `smilies_id` smallint(5) unsigned NOT NULL auto_increment,
								  `code` varchar(50) default NULL,
								  `smile_url` varchar(100) default NULL,
								  `emoticon` varchar(75) default NULL,
								  PRIMARY KEY  (`smilies_id`));";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("smilies",$Erg);
	$strSQL = "INSERT INTO `smilies` (`smilies_id`, `code`, `smile_url`, `emoticon`) VALUES
								(1, ':D', 'icon_biggrin.gif', 'Very Happy'),
								(2, ':-D', 'icon_biggrin.gif', 'Very Happy'),
								(3, ':grin:', 'icon_biggrin.gif', 'Very Happy'),
								(4, ':)', 'icon_smile.gif', 'Smile'),
								(5, ':-)', 'icon_smile.gif', 'Smile'),
								(6, ':smile:', 'icon_smile.gif', 'Smile'),
								(7, ':(', 'icon_sad.gif', 'Sad'),
								(8, ':-(', 'icon_sad.gif', 'Sad'),
								(9, ':sad:', 'icon_sad.gif', 'Sad'),
								(10, ':o', 'icon_surprised.gif', 'Surprised'),
								(11, ':-o', 'icon_surprised.gif', 'Surprised'),
								(12, ':eek:', 'icon_surprised.gif', 'Surprised'),
								(13, ':shock:', 'icon_eek.gif', 'Shocked'),
								(14, ':?', 'icon_confused.gif', 'Confused'),
								(15, ':-?', 'icon_confused.gif', 'Confused'),
								(16, ':???:', 'icon_confused.gif', 'Confused'),
								(17, '8)', 'icon_cool.gif', 'Cool'),
								(18, '8-)', 'icon_cool.gif', 'Cool'),
								(19, ':cool:', 'icon_cool.gif', 'Cool'),
								(20, ':lol:', 'icon_lol.gif', 'Laughing'),
								(21, ':x', 'icon_mad.gif', 'Mad'),
								(22, ':-x', 'icon_mad.gif', 'Mad'),
								(23, ':mad:', 'icon_mad.gif', 'Mad'),
								(24, ':P', 'icon_razz.gif', 'Razz'),
								(25, ':-P', 'icon_razz.gif', 'Razz'),
								(26, ':razz:', 'icon_razz.gif', 'Razz'),
								(27, ':oops:', 'icon_redface.gif', 'Embarassed'),
								(28, ':cry:', 'icon_cry.gif', 'Crying or Very sad'),
								(29, ':evil:', 'icon_evil.gif', 'Evil or Very Mad'),
								(30, ':twisted:', 'icon_twisted.gif', 'Twisted Evil'),
								(31, ':roll:', 'icon_rolleyes.gif', 'Rolling Eyes'),
								(32, ':wink:', 'icon_wink.gif', 'Wink'),
								(33, ';)', 'icon_wink.gif', 'Wink'),
								(34, ';-)', 'icon_wink.gif', 'Wink'),
								(35, ':!:', 'icon_exclaim.gif', 'Exclamation'),
								(36, ':?:', 'icon_question.gif', 'Question'),
								(37, ':idea:', 'icon_idea.gif', 'Idea'),
								(38, ':arrow:', 'icon_arrow.gif', 'Arrow'),
								(39, ':|', 'icon_neutral.gif', 'Neutral'),
								(40, ':-|', 'icon_neutral.gif', 'Neutral'),
								(41, ':neutral:', 'icon_neutral.gif', 'Neutral'),
								(42, ':mrgreen:', 'icon_mrgreen.gif', 'Mr. Green');";
	$Erg = $dbconn->query($strSQL);
	if ($Erg == true)
	echo ("<p><b>smilies</b> Tabelle wurde gef&uuml;llt</p>");

	$strSQL = "CREATE TABLE `chat_log` (
		  `userid` int(11) NOT NULL default '0',
		  `message` text NOT NULL,
		  `Time` int(10) default NULL,
		  `empfänger` int(11) NOT NULL default '0'
		);";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("chat_log",$Erg);
	$strSQL = "CREATE TABLE `chat_online` (
		  `userid` int(11) NOT NULL default '0',
		  `sid` varchar(32) NOT NULL default '',
		  `zeit` int(10) NOT NULL default '0',
		  `ip` int(15) NOT NULL default '0'
		);";
	$Erg = $dbconn->query($strSQL);
    $table_bit.=installtable("chat_online",$Erg);

	$strSQL = "INSERT INTO `login2_users`(`username`,`group`,`password`,`active`,`regdate`,email,style_set) VALUES ('Administrator',2, '21232f297a57a5a743894a0e4a801fc3', 1, " . time() . ",'mail@mail.de',1);";
	$Erg = $dbconn->query($strSQL);
	if ($Erg == true)
	echo ("<p>Der Administrator Account wurde erstellt. Name: <b>Administrator</b> Password: <b>admin</b> </p>");
    eval("echo \"".template("install-3")."\";");
}
?> 
