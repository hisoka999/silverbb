<?php

if (isset ($_COOKIE['postanfang']) && $_COOKIE['postanfang'])
$postanfang = $_COOKIE['postanfang'];
elseif (isset ($_POST['postanfang']) && $_POST['postanfang']) $postanfang = $_POST['postanfang'];
elseif (isset ($_GET['postanfang']) && $_GET['postanfang']) $postanfang = $_GET['postanfang'];
else
$postanfang = 0;
include "dbconnect.inc.php";

include "header.php";
//if(isset($_GET["boardid"]))$boardid=(int)$_GET["boardid"];
//else $boardid=0;
if(isset($_GET["threadid"]))$threadid=(int)$_GET["threadid"];
else $threadid=0;

$thread = $dbconn->query_first("SELECT name,boardid FROM thread WHERE ID=$threadid");
$threadname=$thread["name"];
$boardid=$thread["boardid"];
$boardname = $dbconn->queryone("SELECT name FROM board WHERE ID=".$thread["boardid"]);

eval ("\$header= \"" . template("header") . "\";");

$dbconn->query("UPDATE thread SET visits=visits+1 WHERE ID=$threadid");

$RS = $dbconn->query("SELECT ID,Autor, Datum,threadid,Inhalt 
                        FROM posts
                        WHERE threadid=$threadid
                        ORDER BY ID
                        LIMIT $postanfang,20");
$pos = 1; //@todo miessssssss
$showpost = ""; //@todo miessssssss
$postid = 0; //@todo miessssssss
while ($zeile = $dbconn->fetch_array($RS)) {
	$postid = $zeile["ID"]; //miessssssss
	$zeile["username"] = $zeile["Autor"]; //@todo miessssssss
	$userid = $zeile["Autor"];
	if ($userid)
	$_username = $dbconn->queryone("SELECT username FROM login2_users WHERE ID=" . $userid); //miessssssss
	else
	$_username = "Gast";
	$allposts = 4;
	//      $Date=$zeile["Datum"];
	$Date = strftime("%H:%M %d.%m.%Y", $zeile["Datum"]);
	if (($group['can_edit_own_posts'] == 1 and $username == $_username) or ($group['can_edit_all_posts'] == 1)) {
		$edit = "<a href=post.php?action=edit&step=1&postid=$postid&boardid=$boardid&threadid=$threadid>Editieren</a>";
	} else {
		$edit = "";
	}
	$Inhalt = $zeile["Inhalt"];
	$Inhalt = prepare_code($Inhalt);
	$Inhalt = smilie($Inhalt);
	$Inhalt = "<pre>$Inhalt</pre>";
	$user_id = $userid;
	$usericq = _sql("SELECT icq FROM login2_users WHERE ID='$userid';", "icq");
	if ($usericq != NULL)
	eval ("\$thread_usericq= \"" . template("thread_usericq") . "\";");
	else
	$thread_usericq = "";
	$sig = _sql("SELECT signature FROM login2_users WHERE ID='$userid';", "signature");
	$sig = prepare_code($sig);
	if ($sig != NULL)
	$sig = "<pre><hr>" . $sig . "</pre>";
	if ($group['can_delete_posts'] == 1)
	$postdel = "<a href=actions.php?action=postdel&postid=$postid&boardid=$boardid&threadid=$threadid>Beitrag l&ouml;schen</a>";
	else
	$postdel = "";
	include "userinfo.php";

	eval ("\$showpost.= \"" . template("showpost") . "\";");
}

$count = $dbconn->queryone("SELECT count(*) FROM posts WHERE threadid='$threadid'");
$ausgabe="<td bgcolor=$headerfarbe width=10> <a href=thread.php?boardid=$boardid&threadid=$threadid&action=thread&postanfang=0>1</a></td>";
if($count>20)
for($i=20;$i<$count;$i+=20){
	$ausgabe.="<td bgcolor=$headerfarbe width=10> <a href=thread.php?boardid=$boardid&threadid=$threadid&action=thread&postanfang=$i>".($i/20)."</a></td>";
}
$Adminaction = "";
$close = _SQL("SELECT close FROM thread WHERE ID=$threadid", "close");
if ($group['can_clos_topic'] == 1 and $group['can_delete_topic'] == 1) {
	if ($close == "0")
	$Adminaction = "<form action=actions.php?threadid=$threadid&boardid=$boardid method=post><SELECT class=post NAME='action'><option value='close'>Schlie&szlig;en</option>";
	else
	if ($close == "1")
	$Adminaction = "<form action='actions.php?threadid=$threadid&boardid=$boardid' method='post''><SELECT class=post NAME='action'><option value='close'>&Ouml;ffnen</option>";
	$Adminaction .= "<option value='delete'>L&ouml;schen</option><option value='announce'>Wichtig/unwichtig</option></select>";
	$Adminaction .= "<input type='submit' value=OK></form>";
} else {
	$Adminaction = "";
}
if ($close == "1") {
	$thread = "Thead geschlossen";
} else {
	$thread = "<a href='post.php?boardid=$boardid&action=post&threadid=$threadid&step=1'><img src='$imagefolder/new_post.gif' border=0></a>";
}
if ($group['can_write_topic'] == 1) {
	$post = "<a href='post.php?boardid=$boardid&action=create&step=1'><img src='$imagefolder/new_thread.gif' border=0></a>";
} else
$post = "";
$board_change = board_change($boardid);
eval ("\$footer= \"" . template("footer") . "\";");
eval ("echo( \"" . template("thread_index") . "\");");
?>