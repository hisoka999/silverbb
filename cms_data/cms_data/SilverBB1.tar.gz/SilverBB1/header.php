<?php
/**
 * @author $LastChangedBy: stefan $
 * @copyright &copy; 2007 by www.silver-boards.de
 * @version 0.5
 * @date $LastChangedDate: 2007-11-18 19:34:20 +0100 (So, 18 Nov 2007) $ 
 * @Rev $LastChangedRevision: 22 $ 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */
 
include "acp/classes/db_conn_class.php";
$dbconn= New dbconn;
$dbconn->Server=$Server;
$dbconn->Benutzer=$Benutzer;
$dbconn->Kennwort=$Kennwort;
$dbconn->DB=$DB;
$dbconn->Conn();

if (isset($_GET["action"]))$u_action=$_GET['action'];
else $u_action="";

if(ini_get("register_globals")) $register_globals=true;
else $register_globals=false;
$fctime = 30;
#
if(isset($_COOKIE['sid']) && $_COOKIE['sid']) $sid=$_COOKIE['sid'];
elseif(isset($_POST['sid']) && $_POST['sid']) $sid=$_POST['sid'];
elseif(isset($_GET['sid']) && $_GET['sid']) $sid=$_GET['sid'];
else $sid = "";



if(!$_SERVER['REQUEST_URI']) {
	if($_SERVER['PATH_INFO']) $REQUEST_URI = $_SERVER['PATH_INFO'];
 	else $REQUEST_URI = $_SERVER['PHP_SELF'];
 	if($_SERVER['QUERY_STRING']) $REQUEST_URI .= "?" . $_SERVER['QUERY_STRING'];
}
else 
	$REQUEST_URI = $_SERVER['REQUEST_URI'];
if(!$sid) 
	$sid = session_id();
session_id($sid);
$REMOTE_ADDR = getIpAddress();
if(!isset($_SESSION['ssip'])) {
	#$ssip = getenv("REMOTE_ADDR");
	$ssip = $REMOTE_ADDR;
	mybb_session_register("ssip");
} 
elseif((!strstr($REQUEST_URI,"actions.php") && $_SESSION['ssip']!=$REMOTE_ADDR)) {
	// Cookie vorhanden, wahrscheinlich schon eingeloggt => nicht weiterleiten, sondern nur eine neue session starten.
	if(isset($_COOKIE['user_id']) && intval($_COOKIE['user_id'])>0 && isset($_COOKIE['user_password']))
	{
		session_unset();
		session_destroy();
		#session_name("sid");
		#session_start();
		#$sid=session_id();
	}
	// Session vollkommen killen..
	else
	{
		session_unset();
		session_destroy();
		header("Location: ".basename($REQUEST_URI)."");
		exit;
	}
}
$client_ip = ( !empty($HTTP_SERVER_VARS['REMOTE_ADDR']) ) ? $HTTP_SERVER_VARS['REMOTE_ADDR'] : ( ( !empty($HTTP_ENV_VARS['REMOTE_ADDR']) ) ? $HTTP_ENV_VARS['REMOTE_ADDR'] : $REMOTE_ADDR );
$user_ip = encode_ip($client_ip);
$user_ip = decode_ip($user_ip);
$user_id="";
$user_password="";
if(isset($_COOKIE['user_id']) && intval($_COOKIE['user_id'])>0) $user_id = intval($_COOKIE['user_id']);
elseif(isset($_SESSION['user_id']) && intval($_SESSION['user_id'])>0 && !$user_id) $user_id = intval($_SESSION['user_id']);
else $user_id=0;

if(isset($_COOKIE['user_password']) && $_COOKIE['user_password']) $user_password = ($_COOKIE['user_password']);
elseif(isset($_SESSION['user_password']) && $_SESSION['user_password'] && !$user_password) $user_password = ($_SESSION['user_password']);
else $user_password="";


// $user_id & $user_password verifizieren...
if($user_id && $user_password && check_userdata($user_id,$user_password)) {
	$userdata =$dbconn->query_first("SELECT * FROM login2_users WHERE ID = '$user_id';");    
    if($userdata['blocked']==1) $blocked = 1;
	else $blocked = 0;
    $username = $userdata['username'];
    $user_group = $userdata['group'];
    $old_time = $userdata['lastvisit'];
    $new_time = $userdata['lastactivity'];
    $session_link = $userdata['session_link'];
    $hide_signature = $userdata['signature'];
    $hide_userpic = $userdata['Avatar'];
    $login=1;
    
    if($userdata['style_set']) $styleid = $userdata['style_set'];
    elseif(isset($_GET["styleid"]))$styleid=$_GET["styleid"];
    else $styleid=0;
    if($new_time < (time()-100)) {
    	$old_time = $new_time;
         $new_time = time();
         $dbconn->query("UPDATE `login2_users` set `lastvisit`='$old_time', `lastactivity`='$new_time' WHERE ID=$user_id");
    }
    else {
	    $new_time = time();
         $dbconn->query("UPDATE `login2_users` set `lastactivity`='$new_time' WHERE ID=$user_id");         
    }
}
else {
	$user_id=0;
	$old_time = time();
	$new_time = time();
	$userdata['style_set']=0;
	mybb_session_register("old_time");
	mybb_session_register("new_time");
	$username="Gast";
	$session_link = 0;
	$umaxposts = 0;
	$hide_signature = 0;
	$hide_userpic = 0;
	$prunedays = 0;
	$u_bbcode = 1;
	$blocked=0;
	$login=0;
	$user_group=1;
	$Admincp="";          
  	if(isset($_GET["styleid"]))$styleid=$_GET["styleid"];
  	else $styleid=0;
}

if(isset($_SESSION['url_ak'])) $url_jump = $_SESSION['url_ak'];
else $url_jump = "";
if(!$url_jump) $url_jump = urlencode(basename($REQUEST_URI));
if(!strstr($REQUEST_URI,"actions.php") && !strstr($REQUEST_URI,"register.php") && !strstr($REQUEST_URI,"misc.php")) $url_ak = urlencode($REQUEST_URI);
else $url_ak = $_SESSION['url_ak'];

mybb_session_register("url_ak");
mybb_session_register("url_jump");

$session = "";
$session2 = "";
if(!$session_link) {
	$session = "&sid=".$sid;
	$session2 = "?sid=".$sid;
}
/*--------------------------------------------------------------
Aus laden aller Wichtigen Vasriablen aus der jeweiligen Datenbank
----------------------------------------------------------------*/
$zeile=$dbconn->query_first("Select * from forum");
$forumname=$zeile["name"];
$version=$zeile["Version"];
$adminmail=$zeile["adminmail"];
$localdir=$zeile["localdir"];
$default_style=$zeile["default_style"];
 
if ($styleid==0)$style=$default_style;
else $style=$styleid;
$zeile=$dbconn->query_first("Select * from style WHERE style_id=".$style);
$logo=$zeile["logo"];
$bgcolor=$zeile["hintergrund"];
$forenfarbe=$zeile["forumfarbe"];
$headerfarbe=$zeile["header"];
$imagefolder=$zeile["imagefolder"];
$tplfolder=$zeile["tplfolder"];
$css=$zeile["css"];

include "./acp/classes/template_class.php";  
$tpl=new template;  
  
  
$group=$dbconn->query_first("SELECT * FROM `group` WHERE `groupid` = '$user_group';");
if ($group['can_use_acp']==1)
{
	$Admincp="&nbsp;<a href='acp/index.php' target='_blank'> Admin CP</a> &nbsp;&nbsp;&nbsp;|";
}
else  $Admincp="";


if ($login==1)
{
	# login anfang
	$zeile=$dbconn->query_first("SELECT * FROM login2_users WHERE username = '$username';");    
  	$Avatar="<img src=" . $zeile["Avatar"] . ">";
  	$Profil="<a href='profil.php?action='>Profil</a>&nbsp;&nbsp;&nbsp;| <a href=pms.php?action=&step=list>PM's</a>";
  	$register="";
}
else
{
	$Profil="";
  	$register="<a href='register.php?action=&step=1'>Registrieren</a>&nbsp;&nbsp;&nbsp;|&nbsp;";
}

#--------------Partner--------------
$SQL=$dbconn->query("Select * from partner");
$partner=Null;
while($zeile=$dbconn->fetch_array($SQL))
{
  	$partner.="<a href=".$zeile["P_link"]." target=_blank><img src=".$zeile["P_banner"]." border=0></a><br>";
}


$session_post = "<INPUT TYPE=\"HIDDEN\" NAME=\"sid\" VALUE=\"$sid\">";
if($session) $session_post = "<input type=\"hidden\" name=\"sid\" value=\"$sid\">";

useronline($user_id);
useronline_chat(0);
?>