<?php
$strSQL = "Select * From posts";
Conn();
mysql_select_db($DB, $Conn);
//Verbindung zur mysql-Tabelle aufbauen
$RS2 = mysql_query($strSQL, $Conn);
//Daten ausgeben
$posts = 0;
while ($counter = mysql_fetch_array($RS2, MYSQL_ASSOC)) {
	if ($counter["boardid"] == $boardid AND $allposts == 2) {
		$posts++;
	} else
		if ($allposts == 1) {
			$posts++;
		} else
			if ($counter["threadid"] == $threadid AND $allposts == 3) {
				$posts++;
			} else
				if ($allposts == 4 AND $counter["Autor"] == $zeile["username"]) {
					$posts++;
				}
}
?>